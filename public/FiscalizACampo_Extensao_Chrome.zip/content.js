/**
 * Conserva_Fotos - FiscalizACampo WhatsApp Web
 * Versão 2.4.1 Real HD - Extração Direta de Mídias via WWebJS (whatsapp-web.js), Datas Precisas, Expansão Completa de Álbuns e Armazenamento em Lote no IndexedDB
 * 
 * Funcionalidades principais v2.4.1:
 * 1. Extração Direta de Mídias (WWebJS / whatsapp-web.js):
 *    Recupera Blobs nativos originais sem latência de visualizador e com fallback automático para mídias em memória.
 * 2. Estrutura de Salvamento em Lote no IndexedDB Mantida 100%:
 *    Persistência em disco via TempBlobStorage (IndexedDB), liberando memória RAM e compactando em lotes de 150 fotos.
 * 3. Auto-carregamento e Fallback Seguro de JSZip e XLSX:
 *    Garante que as bibliotecas de compactação ZIP e Excel estejam sempre disponíveis sem mensagens de erro.
 * 4. Fechamento Ativo de Modais / Lightbox do WhatsApp:
 *    Garante que telas de mídia aberta ou "Imagem indisponível" sejam fechadas sem interromper a varredura do chat.
 * 5. Detecção Precisa de Datas: Identifica divisores de data reais do WhatsApp e timestamps nativos sem inventar datas futuras.
 */

(function () {
  'use strict';

  if (window.__fiscalizacampo_injected__) return;
  window.__fiscalizacampo_injected__ = true;

  console.log('[Conserva_Fotos] Extensão v2.4.1 Real HD carregada no WhatsApp Web.');

  // =========================================================================
  // BUNDLE LOCAL SEGURA DE BIBLIOTECAS (JSZIP & XLSX - ZERO CDN EXTERNALIZATION)
  // Carregamento 100% offline via manifest.json (jszip.min.js & xlsx.full.min.js)
  // =========================================================================
  async function ensureLibrariesLoaded() {
    return Boolean(
      (window.JSZip || typeof JSZip !== 'undefined') && 
      (window.XLSX || typeof XLSX !== 'undefined')
    );
  }

  // Inicializa a tentativa de carregamento em segundo plano
  ensureLibrariesLoaded().catch(() => {});

  // =========================================================================
  // SISTEMA DE ARMAZENAMENTO TEMPORÁRIO DE BLOBS EM DISCO (INDEXEDDB)
  // Evita manter centenas/milhares de Blobs pesados no Heap do JavaScript
  // =========================================================================
  const TempBlobStorage = {
    db: null,
    async init() {
      if (this.db) return true;
      return new Promise((resolve) => {
        try {
          const req = indexedDB.open('fac_temp_blob_db', 1);
          req.onupgradeneeded = (e) => {
            const db = e.target.result;
            if (!db.objectStoreNames.contains('blobs')) {
              db.createObjectStore('blobs');
            }
          };
          req.onsuccess = (e) => {
            this.db = e.target.result;
            resolve(true);
          };
          req.onerror = () => {
            this.db = null;
            resolve(false);
          };
        } catch (err) {
          this.db = null;
          resolve(false);
        }
      });
    },
    isAvailable() {
      return Boolean(this.db);
    },
    async store(key, blob) {
      if (!this.db || !blob) return false;
      return new Promise((resolve) => {
        try {
          const tx = this.db.transaction('blobs', 'readwrite');
          const store = tx.objectStore('blobs');
          const req = store.put(blob, key);
          req.onsuccess = () => resolve(true);
          req.onerror = () => resolve(false);
        } catch (e) {
          resolve(false);
        }
      });
    },
    async retrieve(key) {
      if (!this.db) return null;
      return new Promise((resolve) => {
        try {
          const tx = this.db.transaction('blobs', 'readonly');
          const store = tx.objectStore('blobs');
          const req = store.get(key);
          req.onsuccess = (e) => resolve(e.target.result || null);
          req.onerror = () => resolve(null);
        } catch (e) {
          resolve(null);
        }
      });
    },
    async remove(key) {
      if (!this.db) return false;
      return new Promise((resolve) => {
        try {
          const tx = this.db.transaction('blobs', 'readwrite');
          const store = tx.objectStore('blobs');
          const req = store.delete(key);
          req.onsuccess = () => resolve(true);
          req.onerror = () => resolve(false);
        } catch (e) {
          resolve(false);
        }
      });
    },
    async clear() {
      if (!this.db) return false;
      return new Promise((resolve) => {
        try {
          const tx = this.db.transaction('blobs', 'readwrite');
          const store = tx.objectStore('blobs');
          const req = store.clear();
          req.onsuccess = () => resolve(true);
          req.onerror = () => resolve(false);
        } catch (e) {
          resolve(false);
        }
      });
    }
  };

  // Inicializa o banco IndexedDB imediatamente
  TempBlobStorage.init();

  // =========================================================================
  // EXTRAÇÃO DIRETA DE MÍDIAS VIA FUNÇÃO DO GITHUB (whatsapp-web.js - wwebjs)
  // Repositório: https://github.com/wwebjs/whatsapp-web.js/
  // Arquivo de referência: src/util/Injected/Utils.js -> resolveMediaBlob
  // =========================================================================
  window.WWebJS = window.WWebJS || {};

  function getWAWebModule(moduleName) {
    if (typeof window.require === 'function') {
      try {
        return window.require(moduleName);
      } catch (e) {}
    }
    if (window.__fac_wa_require) {
      try {
        return window.__fac_wa_require(moduleName);
      } catch (e) {}
    }
    if (window.webpackChunkwhatsapp_web_client && !window.__fac_wa_require) {
      try {
        window.webpackChunkwhatsapp_web_client.push([
          [Symbol('fac_req_finder')],
          {},
          (r) => {
            window.__fac_wa_require = r;
            if (typeof window.require !== 'function') {
              window.require = r;
            }
          }
        ]);
        if (window.__fac_wa_require) {
          return window.__fac_wa_require(moduleName);
        }
      } catch (e) {}
    }
    return null;
  }

  /**
   * Resolves the media blob and metadata for a message.
   * Shared by downloadMedia and downloadMediaStream.
   * Função oficial do whatsapp-web.js (wwebjs/src/util/Injected/Utils.js)
   */
  window.WWebJS.resolveMediaBlob = async (msgIdOrModel) => {
    try {
      const waCollections = getWAWebModule('WAWebCollections');
      if (!waCollections || !waCollections.Msg) return null;
      const { Msg } = waCollections;

      let msg = null;
      if (msgIdOrModel && typeof msgIdOrModel === 'object' && msgIdOrModel.mediaData) {
        msg = msgIdOrModel;
      } else if (typeof msgIdOrModel === 'string' && msgIdOrModel) {
        msg = Msg.get(msgIdOrModel) || (await Msg.getMessagesById([msgIdOrModel]))?.messages?.[0];
      }

      if (
        !msg ||
        !msg.mediaData ||
        msg.mediaData.mediaStage === 'REUPLOADING'
      ) {
        return null;
      }

      if (typeof msg.downloadMedia === 'function') {
        await msg.downloadMedia({
          downloadEvenIfExpensive: true,
          rmrReason: 1,
          isUserInitiated: true,
        });
      }

      if (
        (msg.mediaData.mediaStage && String(msg.mediaData.mediaStage).includes('ERROR')) ||
        msg.mediaData.mediaStage === 'FETCHING'
      ) {
        return null;
      }

      let cached = null;
      try {
        const memCacheMod = getWAWebModule('WAWebMediaInMemoryBlobCache');
        if (memCacheMod?.InMemoryMediaBlobCache) {
          cached = memCacheMod.InMemoryMediaBlobCache.get(msg.mediaObject?.filehash);
        }
      } catch (e) {}

      let blob = null;
      if (cached) {
        blob = cached;
      } else if (msg.mediaObject?.mediaBlob && typeof msg.mediaObject.mediaBlob.forceToBlob === 'function') {
        blob = msg.mediaObject.mediaBlob.forceToBlob();
      }

      if (!blob) return null;

      return {
        blob,
        mimetype: msg.mimetype || blob.type || 'image/jpeg',
        filename: msg.filename || `foto_${msg.id?._serialized || Date.now()}.jpg`,
        filesize: msg.size || blob.size,
        timestamp: msg.t ? msg.t * 1000 : null,
        caption: msg.caption || msg.body || '',
        messageModel: msg,
      };
    } catch (err) {
      return null;
    }
  };

  /**
   * Invoca a extração direta de mídia de forma síncrona/imediata sem timeouts longos
   */
  async function requestResolveMedia(msgIdOrModel) {
    if (!msgIdOrModel) return null;

    if (typeof window.WWebJS?.resolveMediaBlob === 'function') {
      try {
        const direct = await window.WWebJS.resolveMediaBlob(msgIdOrModel);
        if (direct && direct.blob) {
          return direct;
        }
      } catch (e) {}
    }

    return null;
  }

  // =========================================================================
  // ESTADO GLOBAL DA EXTENSÃO & CRONÔMETRO DE PROCESSAMENTO (v2.9.4)
  // =========================================================================
  let isScanning = false;
  let shouldStopScanning = false;
  let scanMode = 'chat'; // 'chat' | 'gallery'
  let sleepCancelResolver = null;
  let minDateReached = null;
  let currentDateReading = 'Hoje';
  let currentScanRunId = 0;
  let finishReason = 'END_OF_CHAT'; // 'USER_STOPPED' | 'LIMIT_REACHED' | 'DATE_REACHED' | 'END_OF_CHAT' | 'TIMEOUT_STAGNANT' | 'ERROR'

  // Cronômetro de tempo de processamento em tempo real
  let scanStartTime = null;
  let scanTimerInterval = null;

  function formatElapsedTime(totalSeconds) {
    if (!totalSeconds || isNaN(totalSeconds) || totalSeconds < 0) return '00:00';
    const hrs = Math.floor(totalSeconds / 3600);
    const mins = Math.floor((totalSeconds % 3600) / 60);
    const secs = totalSeconds % 60;
    if (hrs > 0) {
      return `${String(hrs).padStart(2, '0')}:${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
    }
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  }

  function formatElapsedTimeVerbose(totalSeconds) {
    if (!totalSeconds || totalSeconds <= 0) return '0 seg';
    const hrs = Math.floor(totalSeconds / 3600);
    const mins = Math.floor((totalSeconds % 3600) / 60);
    const secs = totalSeconds % 60;
    const parts = [];
    if (hrs > 0) parts.push(`${hrs}h`);
    if (mins > 0) parts.push(`${mins} min`);
    if (secs > 0 || parts.length === 0) parts.push(`${secs} seg`);
    return parts.join(' ');
  }

  function startScanTimer() {
    if (scanTimerInterval) clearInterval(scanTimerInterval);
    scanStartTime = Date.now();
    const timerEl = document.getElementById('fac-stat-timer');
    if (timerEl) timerEl.textContent = '00:00';

    scanTimerInterval = setInterval(() => {
      if (!scanStartTime) return;
      const elapsed = Math.floor((Date.now() - scanStartTime) / 1000);
      const el = document.getElementById('fac-stat-timer');
      if (el) el.textContent = formatElapsedTime(elapsed);
    }, 1000);
  }

  function stopScanTimer() {
    if (scanTimerInterval) {
      clearInterval(scanTimerInterval);
      scanTimerInterval = null;
    }
    if (scanStartTime) {
      const elapsed = Math.floor((Date.now() - scanStartTime) / 1000);
      const el = document.getElementById('fac-stat-timer');
      if (el) el.textContent = formatElapsedTime(elapsed);
      return elapsed;
    }
    return 0;
  }

  // Registro de alertas de álbuns que atingiram o teto de segurança
  const albumCeilingWarnings = [];

  // photoKey -> { key, meta, rawText, isHd, isThumbnail, resolutionCategory, width, height, size, timestamp, cappedAlbum, blob }
  const photoAccumulator = new Map();

  let floatingBtn = null;
  let panel = null;
  let globalStopBar = null;

  // Lote de fotos por arquivo ZIP para garantir download fluido e liberação real de memória
  const MAX_PHOTOS_PER_ZIP_BATCH = 150;
  // Teto seguro de fotos por álbum antes de interromper e emitir alerta
  const MAX_ALBUM_PHOTOS = 80;

  // =========================================================================
  // FUNÇÕES AUXILIARES DE FORMATAÇÃO E SANITIZAÇÃO
  // =========================================================================
  function formatDateToYMD(d) {
    if (!d || isNaN(d.getTime())) return '';
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }

  function formatDisplayDate(d) {
    if (!d || isNaN(d.getTime())) return '';
    const day = String(d.getDate()).padStart(2, '0');
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const year = d.getFullYear();
    return `${day}/${month}/${year}`;
  }

  function sanitizeForFilename(str, fallback = '') {
    if (!str || typeof str !== 'string') return fallback;
    const clean = str
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-zA-Z0-9_\-]/g, '_')
      .replace(/_+/g, '_')
      .replace(/^_+|_+$/g, '')
      .toUpperCase();
    return clean || fallback;
  }

  function interruptibleSleep(ms) {
    return new Promise((resolve) => {
      let timer = null;
      const onWake = () => {
        if (timer) clearTimeout(timer);
        sleepCancelResolver = null;
        resolve();
      };
      timer = setTimeout(onWake, ms);
      sleepCancelResolver = onWake;
    });
  }

  /**
   * Espera condicional limitada por timeout
   */
  async function waitForCondition(predicateFn, options = {}) {
    const timeoutMs = options.timeoutMs || 2500;
    const intervalMs = options.intervalMs || 60;
    const startTime = Date.now();

    while (!shouldStopScanning) {
      try {
        const res = await predicateFn();
        if (res) return res;
      } catch (e) {}

      if (Date.now() - startTime >= timeoutMs) {
        return null;
      }

      await interruptibleSleep(intervalMs);
    }
    return null;
  }

  let lastCapturedPhotoDateStr = 'Nenhuma';

  function updateLastPhotoDateDisplay(dateText) {
    if (!dateText || dateText === 'Não identificada' || dateText === 'SEM_DATA') return;
    lastCapturedPhotoDateStr = dateText;
    const statLastDate = document.getElementById('fac-stat-last-photo-date');
    if (statLastDate) {
      statLastDate.textContent = dateText;
    }
  }

  function triggerStop() {
    console.log('[Conserva_Fotos] Parada imediata solicitada pelo usuário!');
    shouldStopScanning = true;
    finishReason = 'USER_STOPPED';

    if (sleepCancelResolver) {
      sleepCancelResolver();
    }

    dismissUnwantedModals();

    const statusText = document.getElementById('fac-status-text');
    if (statusText) {
      statusText.textContent = `⏹️ Parando varredura... Finalizando pacote com ${photoAccumulator.size} fotos coletadas...`;
    }
    const stopBtn = document.getElementById('fac-btn-stop');
    if (stopBtn) {
      stopBtn.textContent = '⏹️ Finalizando Download... Aguarde...';
      stopBtn.style.opacity = '0.7';
    }
    const floatStopBtn = document.getElementById('fac-floating-stop-btn');
    if (floatStopBtn) {
      floatStopBtn.textContent = '⏹️ Parando e baixando...';
    }
  }

  function triggerCancelWithoutDownload() {
    console.log('[Conserva_Fotos] Cancelamento sem download solicitado pelo usuário!');
    shouldStopScanning = true;
    finishReason = 'USER_CANCELLED_NO_DOWNLOAD';

    if (sleepCancelResolver) {
      sleepCancelResolver();
    }

    stopScanTimer();
    dismissUnwantedModals();
    closeMediaViewer();

    photoAccumulator.clear();
    try { TempBlobStorage.clear(); } catch (e) {}

    const statusText = document.getElementById('fac-status-text');
    if (statusText) {
      statusText.textContent = '⏹️ Varredura cancelada pelo usuário. Nenhum arquivo foi baixado.';
    }

    const runningActions = document.getElementById('fac-running-actions');
    const startBtn = document.getElementById('fac-btn-start-auto');
    const progressFill = document.getElementById('fac-progress-fill');
    const stopCount = document.getElementById('fac-stop-count');
    const floatingCount = document.getElementById('fac-floating-count');
    const statPhotos = document.getElementById('fac-stat-photos');

    if (runningActions) runningActions.classList.add('hidden');
    if (startBtn) startBtn.classList.remove('hidden');
    if (progressFill) progressFill.style.width = '0%';
    if (stopCount) stopCount.textContent = '0';
    if (floatingCount) floatingCount.textContent = '0';
    if (statPhotos) statPhotos.textContent = '0';

    isScanning = false;
  }

  function updateLiveDateDisplay(dateText) {
    if (!dateText) return;
    currentDateReading = dateText;

    const floatingDate = document.getElementById('fac-floating-date');
    if (floatingDate) {
      floatingDate.textContent = dateText;
    }

    const statDate = document.getElementById('fac-stat-date');
    if (statDate) {
      statDate.textContent = dateText;
    }
  }

  function dismissErrorDialogs() {
    try {
      const dialogs = document.querySelectorAll('div[role="dialog"], div[data-testid="popup-contents"], div[class*="popup"]');
      for (const d of dialogs) {
        if (d.id === 'fiscalizacampo-panel' || d.closest('#fiscalizacampo-panel') || d.closest('#fac-global-stop-bar')) continue;
        const text = (d.innerText || d.textContent || '').toLowerCase();
        if (
          text.includes('indisponível') ||
          text.includes('não está mais no seu celular') ||
          text.includes('não é possível abrir') ||
          text.includes('download failed') ||
          text.includes('falha ao carregar') ||
          text.includes('arquivo corrompido')
        ) {
          const okBtn = Array.from(d.querySelectorAll('button, div[role="button"]')).find((b) => {
            const bt = (b.innerText || b.textContent || '').trim().toLowerCase();
            return bt === 'ok' || bt.includes('ok') || bt.includes('fechar') || bt.includes('entendi');
          }) || d.querySelector('button, div[role="button"]');

          if (okBtn && okBtn.id !== 'fac-close-btn') {
            try { okBtn.click(); } catch (e) {}
          }
        }
      }
    } catch (e) {}
  }

  function closeMediaViewer() {
    // Não fecha o visualizador automaticamente para não interromper a navegação contínua
  }

  function dismissUnwantedModals() {
    dismissErrorDialogs();
  }

  // =========================================================================
  // DECODIFICAÇÃO REAL DE IMAGEM E RESOLUÇÃO
  // =========================================================================
  async function getImageDimensionsFromBlob(blob) {
    if (!blob) return { width: 0, height: 0 };
    try {
      if (typeof createImageBitmap === 'function') {
        const bmp = await createImageBitmap(blob);
        const dims = { width: bmp.width, height: bmp.height };
        bmp.close();
        return dims;
      }
    } catch (e) {}

    return new Promise((resolve) => {
      const url = URL.createObjectURL(blob);
      const img = new Image();
      img.onload = () => {
        resolve({ width: img.naturalWidth || 0, height: img.naturalHeight || 0 });
        URL.revokeObjectURL(url);
      };
      img.onerror = () => {
        resolve({ width: 0, height: 0 });
        URL.revokeObjectURL(url);
      };
      img.src = url;
    });
  }

  async function fetchBlobDirectly(srcUrl) {
    if (!srcUrl || (!srcUrl.startsWith('blob:') && !srcUrl.startsWith('http') && !srcUrl.startsWith('data:image'))) return null;
    try {
      const res = await fetch(srcUrl);
      if (!res.ok) return null;
      const blob = await res.blob();
      return blob;
    } catch (e) {
      return null;
    }
  }

  /**
   * Extração via Canvas oculto para imagens decodificadas no DOM (Zero Dependência de Fetch)
   */
  async function captureImageViaCanvas(img) {
    if (!img) return null;
    try {
      if (!img.complete || img.naturalWidth === 0) {
        await new Promise((res) => {
          if (img.complete && img.naturalWidth > 0) return res();
          img.onload = () => res();
          img.onerror = () => res();
          setTimeout(res, 800);
        });
      }
      const w = img.naturalWidth || img.width || 0;
      const h = img.naturalHeight || img.height || 0;
      if (w === 0 || h === 0) return null;

      const canvas = document.createElement('canvas');
      canvas.width = w;
      canvas.height = h;
      const ctx = canvas.getContext('2d');
      ctx.drawImage(img, 0, 0, w, h);

      return new Promise((resolve) => {
        canvas.toBlob((blob) => {
          resolve(blob);
        }, 'image/jpeg', 0.95);
      });
    } catch (e) {
      return null;
    }
  }

  /**
   * Pipeline de extração imediata com hierarquia resiliente:
   * 1. Resolução Direta WWebJS
   * 2. Blob URL nativo do WhatsApp
   * 3. Canvas offscreen
   */
  async function extractBlobFromImageElement(img, targetMsgId) {
    if (!img) return null;

    // 1. Tenta extração direta via WWebJS se houver ID de mensagem
    if (targetMsgId) {
      try {
        const direct = await requestResolveMedia(targetMsgId);
        if (direct && direct.blob && direct.blob.size >= 400) {
          const dims = await getImageDimensionsFromBlob(direct.blob);
          const isRealHd = dims.width >= 500 || dims.height >= 500 || direct.blob.size >= 35000;
          return {
            blob: direct.blob,
            dims,
            isHd: isRealHd,
            category: isRealHd ? 'Alta Resolução (Dados Diretos WhatsApp)' : 'Média Resolução (WhatsApp)',
            timestamp: direct.timestamp,
          };
        }
      } catch (e) {}
    }

    // 2. Fetch direto da URL Blob (descriptografada pelo React do WhatsApp no DOM)
    const src = img.src || '';
    if (src.startsWith('blob:')) {
      const blob = await fetchBlobDirectly(src);
      if (blob && blob.size >= 400) {
        const dims = await getImageDimensionsFromBlob(blob);
        const isRealHd = dims.width >= 500 || dims.height >= 500 || blob.size >= 35000;
        return {
          blob,
          dims,
          isHd: isRealHd,
          category: isRealHd ? 'Alta Resolução (Blob Decodificado)' : 'Média Resolução (Blob)',
          timestamp: null,
        };
      }
    }

    // 3. Fallback: Captura via Canvas do elemento renderizado
    const canvasBlob = await captureImageViaCanvas(img);
    if (canvasBlob && canvasBlob.size >= 400) {
      const dims = { width: img.naturalWidth || 0, height: img.naturalHeight || 0 };
      const isRealHd = dims.width >= 500 || dims.height >= 500 || canvasBlob.size >= 35000;
      return {
        blob: canvasBlob,
        dims,
        isHd: isRealHd,
        category: isRealHd ? 'Alta Resolução (Canvas Decodificado)' : 'Média Resolução (Canvas)',
        timestamp: null,
      };
    }

    // 4. Última tentativa: se for URL de dados Base64
    if (src.startsWith('data:image')) {
      const b64Blob = await fetchBlobDirectly(src);
      if (b64Blob && b64Blob.size >= 400) {
        const dims = await getImageDimensionsFromBlob(b64Blob);
        return {
          blob: b64Blob,
          dims,
          isHd: false,
          category: 'Miniatura Base64 (Prévia WhatsApp)',
          timestamp: null,
        };
      }
    }

    return null;
  }

  // =========================================================================
  // INTERFACE FLUTUANTE
  // =========================================================================
  function initExtensionUI() {
    if (document.getElementById('fiscalizacampo-floating-btn')) return;

    // 1. Botão Flutuante Circular de Abertura
    floatingBtn = document.createElement('div');
    floatingBtn.id = 'fiscalizacampo-floating-btn';
    floatingBtn.title = 'Conserva_Fotos: Clique para abrir o painel ou arraste para mover este botão';
    floatingBtn.innerHTML = `
      <span class="fac-drag-handle" title="Arraste para mover">
        <svg width="10" height="14" viewBox="0 0 16 24" fill="currentColor">
          <circle cx="4" cy="5" r="2.2"/><circle cx="12" cy="5" r="2.2"/>
          <circle cx="4" cy="12" r="2.2"/><circle cx="12" cy="12" r="2.2"/>
          <circle cx="4" cy="19" r="2.2"/><circle cx="12" cy="19" r="2.2"/>
        </svg>
      </span>
      <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
        <path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z"/>
        <circle cx="12" cy="13" r="3"/>
      </svg>
      <span>Conserva_Fotos</span>
    `;

    try {
      const savedPos = JSON.parse(localStorage.getItem('fac_floating_btn_pos') || 'null');
      if (savedPos && typeof savedPos.top === 'number' && typeof savedPos.left === 'number') {
        const maxLeft = Math.max(10, window.innerWidth - 180);
        const maxTop = Math.max(10, window.innerHeight - 50);
        const left = Math.min(Math.max(10, savedPos.left), maxLeft);
        const top = Math.min(Math.max(10, savedPos.top), maxTop);
        floatingBtn.style.left = `${left}px`;
        floatingBtn.style.top = `${top}px`;
        floatingBtn.style.right = 'auto';
        floatingBtn.style.bottom = 'auto';
      }
    } catch (e) {}

    // 2. Painel de Controle Principal
    panel = document.createElement('div');
    panel.id = 'fiscalizacampo-panel';
    panel.className = 'hidden';

    const savedDate = localStorage.getItem('fac_saved_date_limit');
    const defaultDate = savedDate || `${new Date().getFullYear()}-01-01`;
    const savedEmpresa = localStorage.getItem('fac_saved_empresa') || '';
    const savedArea = localStorage.getItem('fac_saved_area') || '';
    const savedEquipe = localStorage.getItem('fac_saved_equipe') || '';
    const savedNamingPattern = localStorage.getItem('fac_saved_naming_pattern') || 'EMPRESA_AREA_DATA_SEQ';
    let savedMaxPhotos = localStorage.getItem('fac_saved_max_photos') || '0';
    if (savedMaxPhotos === '100') {
      // Migração da versão anterior: garante que não fique limitado a 100 fotos por padrão
      savedMaxPhotos = '0';
      localStorage.setItem('fac_saved_max_photos', '0');
    }

    panel.innerHTML = `
      <div class="fac-header" id="fac-panel-header">
        <div style="display: flex; align-items: center; gap: 8px;">
          <span class="fac-drag-handle" title="Clique e arraste para mover o painel na tela">
            <svg width="10" height="14" viewBox="0 0 16 24" fill="currentColor">
              <circle cx="4" cy="5" r="2.2"/><circle cx="12" cy="5" r="2.2"/>
              <circle cx="4" cy="12" r="2.2"/><circle cx="12" cy="12" r="2.2"/>
              <circle cx="4" cy="19" r="2.2"/><circle cx="12" cy="19" r="2.2"/>
            </svg>
          </span>
          <h3>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z"/>
              <circle cx="12" cy="13" r="3"/>
            </svg>
            Conserva_Fotos
            <span class="fac-badge-ver">v3.1.4</span>
          </h3>
        </div>
        <button class="fac-close-btn" id="fac-close-btn">&times;</button>
      </div>

      <div class="fac-body">
        <div class="fac-group-badge">
          <div style="display: flex; align-items: center; justify-content: space-between; gap: 6px; margin-bottom: 3px;">
            <span>Conversa / Grupo no WhatsApp:</span>
            <button type="button" id="fac-btn-refresh-group" style="background: rgba(245, 158, 11, 0.15); border: 1px solid rgba(245, 158, 11, 0.4); color: #fbbf24; border-radius: 6px; padding: 2px 7px; font-size: 11px; font-weight: 600; cursor: pointer; display: flex; align-items: center; gap: 4px;" title="Clique para ler o nome do grupo aberto no WhatsApp">
              🔄 Ler Grupo
            </button>
          </div>
          <input type="text" id="fac-active-group-name" value="Detectando conversa..." />
        </div>

        <div class="fac-grid-2">
          <div>
            <label class="fac-field-label">🏢 Empresa:</label>
            <input type="text" id="fac-empresa" class="fac-input" placeholder="Ex: MENSORI" value="${savedEmpresa}" />
          </div>
          <div>
            <label class="fac-field-label">📍 Área / Frente:</label>
            <input type="text" id="fac-area" class="fac-input" placeholder="Ex: CL" value="${savedArea}" />
          </div>
        </div>

        <div class="fac-date-section">
          <div class="fac-date-header">
            <label class="fac-field-label" style="margin: 0;">📅 Até qual data buscar?</label>
            <label class="fac-checkbox-label">
              <input type="checkbox" id="fac-date-all" />
              <span>Sem limite</span>
            </label>
          </div>

          <div id="fac-date-input-wrap">
            <input type="date" id="fac-date-limit" class="fac-input" value="${defaultDate}" />
          </div>

          <div class="fac-quick-buttons">
            <button type="button" class="fac-quick-btn" data-days="0">Hoje</button>
            <button type="button" class="fac-quick-btn" data-days="7">7 dias</button>
            <button type="button" class="fac-quick-btn" data-days="15">15 dias</button>
            <button type="button" class="fac-quick-btn" data-days="30">30 dias</button>
            <button type="button" class="fac-quick-btn" data-preset="jan1">01/Jan</button>
          </div>
        </div>

        <div style="margin-top: 4px; display: flex; flex-direction: column; align-items: center; width: 100%;">
          <button id="fac-btn-start-auto" class="fac-btn-primary" style="width: 100%; display: flex; align-items: center; justify-content: center; text-align: center; font-size: 13px; padding: 11px; font-weight: 800; background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);">
            🚀 Iniciar Download Automático
          </button>
          
          <div id="fac-running-actions" class="hidden" style="width: 100%; display: flex; flex-direction: column; gap: 6px;">
            <button id="fac-btn-stop" class="fac-btn-stop" style="width: 100%; display: flex; align-items: center; justify-content: center; text-align: center; font-size: 12px; padding: 11px; font-weight: 700;">
              ⏹️ PARAR E BAIXAR AGORA (<span id="fac-stop-count">0</span> fotos)
            </button>
            <button id="fac-btn-cancel-only" type="button" class="fac-btn-cancel" style="width: 100%; display: flex; align-items: center; justify-content: center; text-align: center; font-size: 11px; padding: 8px; font-weight: 700; background: #27272a; border: 1px solid #3f3f46; color: #fb7185; border-radius: 8px; cursor: pointer; transition: all 0.15s;">
              🚫 APENAS PARAR (SEM BAIXAR)
            </button>
          </div>
        </div>

        <div id="fac-live-status-box" class="fac-live-box hidden">
          <div class="fac-live-header">
            <span class="fac-pulsing-dot"></span>
            <strong>LENDO FOTOS NO WHATSAPP</strong>
          </div>
          <div class="fac-stats-grid">
            <div class="fac-stat-card highlight">
              <span class="fac-stat-title">📅 Data Lida</span>
              <span class="fac-stat-date-highlight" id="fac-stat-date">Lendo...</span>
            </div>
            <div class="fac-stat-card highlight" style="border-color: rgba(52, 211, 153, 0.4);">
              <span class="fac-stat-title">🖼️ Última Foto</span>
              <span class="fac-stat-date-highlight" id="fac-stat-last-photo-date" style="color: #34d399;">Nenhuma</span>
            </div>
            <div class="fac-stat-card">
              <span class="fac-stat-title">📸 Fotos</span>
              <span class="fac-stat-val" id="fac-stat-photos">0</span>
            </div>
            <div class="fac-stat-card">
              <span class="fac-stat-title">⏱️ Tempo</span>
              <span class="fac-stat-val" id="fac-stat-timer" style="color: #fbbf24;">00:00</span>
            </div>
          </div>
          <div class="fac-progress-bar">
            <div id="fac-progress-fill" class="fac-progress-fill"></div>
          </div>
          <div id="fac-status-text" class="fac-status-text">Iniciando...</div>
        </div>
      </div>
    `;

    document.body.appendChild(floatingBtn);
    document.body.appendChild(panel);

    let isDragging = false;
    let hasDragged = false;
    let startX = 0;
    let startY = 0;
    let initialLeft = 0;
    let initialTop = 0;

    const onPointerDown = (e) => {
      if (e.button !== undefined && e.button !== 0) return;
      isDragging = true;
      hasDragged = false;
      const rect = floatingBtn.getBoundingClientRect();
      startX = e.clientX || (e.touches && e.touches[0].clientX) || 0;
      startY = e.clientY || (e.touches && e.touches[0].clientY) || 0;
      initialLeft = rect.left;
      initialTop = rect.top;

      window.addEventListener('pointermove', onPointerMove, { passive: true });
      window.addEventListener('pointerup', onPointerUp);
      window.addEventListener('pointercancel', onPointerUp);
    };

    const onPointerMove = (e) => {
      if (!isDragging) return;
      const currentX = e.clientX || (e.touches && e.touches[0].clientX) || 0;
      const currentY = e.clientY || (e.touches && e.touches[0].clientY) || 0;
      const dx = currentX - startX;
      const dy = currentY - startY;

      if (Math.abs(dx) > 3 || Math.abs(dy) > 3) {
        hasDragged = true;
      }

      const newLeft = Math.max(8, Math.min(window.innerWidth - 170, initialLeft + dx));
      const newTop = Math.max(8, Math.min(window.innerHeight - 45, initialTop + dy));

      floatingBtn.style.left = `${newLeft}px`;
      floatingBtn.style.top = `${newTop}px`;
      floatingBtn.style.right = 'auto';
      floatingBtn.style.bottom = 'auto';
    };

    const onPointerUp = () => {
      if (!isDragging) return;
      isDragging = false;
      window.removeEventListener('pointermove', onPointerMove);
      window.removeEventListener('pointerup', onPointerUp);
      window.removeEventListener('pointercancel', onPointerUp);

      if (hasDragged) {
        const rect = floatingBtn.getBoundingClientRect();
        try {
          localStorage.setItem('fac_floating_btn_pos', JSON.stringify({ top: rect.top, left: rect.left }));
        } catch (e) {}
      }
    };

    floatingBtn.addEventListener('pointerdown', onPointerDown);

    // =========================================================================
    // ARRASTE DO PAINEL PRINCIPAL (PAINEL FLUTUANTE)
    // =========================================================================
    try {
      const savedPanelPos = JSON.parse(localStorage.getItem('fac_panel_pos') || 'null');
      if (savedPanelPos && typeof savedPanelPos.top === 'number' && typeof savedPanelPos.left === 'number') {
        const maxLeft = Math.max(10, window.innerWidth - 330);
        const maxTop = Math.max(10, window.innerHeight - 250);
        panel.style.left = `${Math.min(Math.max(10, savedPanelPos.left), maxLeft)}px`;
        panel.style.top = `${Math.min(Math.max(10, savedPanelPos.top), maxTop)}px`;
        panel.style.right = 'auto';
        panel.style.bottom = 'auto';
      }
    } catch (e) {}

    const panelHeader = panel.querySelector('#fac-panel-header');
    if (panelHeader) {
      let isPanelDragging = false;
      let panelStartX = 0;
      let panelStartY = 0;
      let panelInitialLeft = 0;
      let panelInitialTop = 0;

      const onPanelPointerDown = (e) => {
        if (e.target.closest('#fac-close-btn') || (e.button !== undefined && e.button !== 0)) return;
        isPanelDragging = true;
        const rect = panel.getBoundingClientRect();
        panelStartX = e.clientX || (e.touches && e.touches[0].clientX) || 0;
        panelStartY = e.clientY || (e.touches && e.touches[0].clientY) || 0;
        panelInitialLeft = rect.left;
        panelInitialTop = rect.top;

        window.addEventListener('pointermove', onPanelPointerMove, { passive: true });
        window.addEventListener('pointerup', onPanelPointerUp);
        window.addEventListener('pointercancel', onPanelPointerUp);
      };

      const onPanelPointerMove = (e) => {
        if (!isPanelDragging) return;
        const currentX = e.clientX || (e.touches && e.touches[0].clientX) || 0;
        const currentY = e.clientY || (e.touches && e.touches[0].clientY) || 0;
        const dx = currentX - panelStartX;
        const dy = currentY - panelStartY;

        const newLeft = Math.max(8, Math.min(window.innerWidth - 320, panelInitialLeft + dx));
        const newTop = Math.max(8, Math.min(window.innerHeight - 180, panelInitialTop + dy));

        panel.style.left = `${newLeft}px`;
        panel.style.top = `${newTop}px`;
        panel.style.right = 'auto';
        panel.style.bottom = 'auto';
      };

      const onPanelPointerUp = () => {
        if (!isPanelDragging) return;
        isPanelDragging = false;
        window.removeEventListener('pointermove', onPanelPointerMove);
        window.removeEventListener('pointerup', onPanelPointerUp);
        window.removeEventListener('pointercancel', onPanelPointerUp);

        const rect = panel.getBoundingClientRect();
        try {
          localStorage.setItem('fac_panel_pos', JSON.stringify({ top: rect.top, left: rect.left }));
        } catch (e) {}
      };

      panelHeader.addEventListener('pointerdown', onPanelPointerDown);
    }

    floatingBtn.addEventListener('click', () => {
      if (hasDragged) {
        hasDragged = false;
        return;
      }
      panel.classList.toggle('hidden');
      updateActiveGroupName();
      updateNamingPreview();
    });

    panel.querySelector('#fac-close-btn').addEventListener('click', () => {
      panel.classList.add('hidden');
    });

    const empresaInput = panel.querySelector('#fac-empresa');
    const areaInput = panel.querySelector('#fac-area');

    if (empresaInput) {
      empresaInput.addEventListener('input', () => {
        localStorage.setItem('fac_saved_empresa', empresaInput.value);
      });
    }
    if (areaInput) {
      areaInput.addEventListener('input', () => {
        localStorage.setItem('fac_saved_area', areaInput.value);
      });
    }

    const refreshGroupBtn = panel.querySelector('#fac-btn-refresh-group');
    if (refreshGroupBtn) {
      const handleReadGroup = (e) => {
        if (e) {
          e.preventDefault();
          e.stopPropagation();
        }
        const groupInput = document.getElementById('fac-active-group-name');
        const detected = getActiveGroupName();
        if (groupInput) {
          groupInput.value = detected;
          groupInput.dispatchEvent(new Event('input', { bubbles: true }));
          groupInput.dispatchEvent(new Event('change', { bubbles: true }));
        }
        refreshGroupBtn.textContent = '✅ Copiado!';
        setTimeout(() => {
          refreshGroupBtn.textContent = '🔄 Ler Grupo';
        }, 1500);
      };

      refreshGroupBtn.addEventListener('click', handleReadGroup);
      refreshGroupBtn.addEventListener('pointerdown', (e) => e.stopPropagation());
    }

    const dateLimitInput = panel.querySelector('#fac-date-limit');
    const dateAllCheck = panel.querySelector('#fac-date-all');
    const dateHint = panel.querySelector('#fac-date-hint');

    dateAllCheck.addEventListener('change', () => {
      if (dateAllCheck.checked) {
        dateLimitInput.disabled = true;
        dateLimitInput.style.opacity = '0.4';
        dateHint.textContent = 'Buscando sem limite de data (ou até o limite de fotos configurado).';
      } else {
        dateLimitInput.disabled = false;
        dateLimitInput.style.opacity = '1';
        dateHint.textContent = 'A varredura para automaticamente assim que fotos com esta data forem ultrapassadas.';
      }
    });

    dateLimitInput.addEventListener('change', () => {
      localStorage.setItem('fac_saved_date_limit', dateLimitInput.value);
    });

    panel.querySelectorAll('.fac-quick-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        const days = btn.getAttribute('data-days');
        const preset = btn.getAttribute('data-preset');

        dateAllCheck.checked = false;
        dateLimitInput.disabled = false;
        dateLimitInput.style.opacity = '1';

        const d = new Date();
        if (preset === 'jan1') {
          d.setMonth(0, 1);
        } else if (days !== null) {
          d.setDate(d.getDate() - parseInt(days, 10));
        }

        dateLimitInput.value = formatDateToYMD(d);
        localStorage.setItem('fac_saved_date_limit', dateLimitInput.value);
        dateHint.textContent = `Buscando histórico até ${formatDisplayDate(d)}.`;
      });
    });

    // 1 ÚNICO BOTÃO DE INÍCIO
    panel.querySelector('#fac-btn-start-auto').addEventListener('click', () => {
      scanMode = 'viewer';
      startScanWorkflow();
    });

    // Botões de Parar e Cancelar
    panel.querySelector('#fac-btn-stop').addEventListener('click', triggerStop);
    const cancelOnlyBtn = panel.querySelector('#fac-btn-cancel-only');
    if (cancelOnlyBtn) {
      cancelOnlyBtn.addEventListener('click', triggerCancelWithoutDownload);
    }
  }

  function getActiveGroupName() {
    function isBadCandidate(str) {
      if (!str || typeof str !== 'string') return true;
      const lower = str.toLowerCase().trim();
      return (
        lower.length < 2 ||
        lower.includes('atualizações') ||
        lower.includes('status') ||
        lower.includes('canais') ||
        lower.includes('comunidade') ||
        lower.includes('chamada') ||
        lower.includes('pesquisar') ||
        lower.includes('anexar') ||
        lower.includes('menu') ||
        lower.includes('silenciar') ||
        lower.includes('dados do grupo') ||
        lower.includes('dados do contato') ||
        lower.includes('visto por último') ||
        lower.includes('online') ||
        lower.includes('digitando') ||
        lower.includes('gravando') ||
        lower.includes('mensagens temporárias') ||
        lower.includes('clique para') ||
        lower.includes('toque para') ||
        lower === 'whatsapp' ||
        lower === 'hoje' ||
        lower === 'ontem'
      );
    }

    function isMemberList(str) {
      if (!str) return false;
      const commas = (str.match(/,/g) || []).length;
      if (commas >= 2) return true;
      if (commas >= 1 && (str.includes('+55') || str.includes('Coord') || str.includes('Eng°') || str.includes('você') || str.includes('Você'))) return true;
      if (str.includes('+55') && str.length > 20) return true;
      return false;
    }

    // 1. PRIORIDADE MÁXIMA: Cabeçalho da conversa aberta (#main header)
    const mainHeader = document.querySelector('#main header, div[data-testid="conversation-header"]');
    if (mainHeader) {
      // Localiza especificamente o primeiro título de texto dentro do botão de informações do chat
      const titleSelectors = [
        '#main header [data-testid="conversation-info-header"] span[title]',
        '#main header [data-testid="conversation-info-header"] span[dir="auto"]',
        '#main header div[role="button"] span[title]',
        '#main header div[role="button"] span[dir="auto"]',
        '#main header h2 span',
        '#main header h2',
        '#main header span[title]',
      ];

      for (const sel of titleSelectors) {
        const elements = Array.from(mainHeader.querySelectorAll(sel));
        for (const el of elements) {
          if (el.closest('#fiscalizacampo-panel') || el.closest('#fac-global-stop-bar') || el.closest('#fiscalizacampo-floating-btn')) continue;
          if (el.closest('button:not([role="button"]), [data-testid="menu"], [data-testid="search"], [data-testid="voice-call"]')) continue;

          const raw = (el.getAttribute('title') || el.innerText || el.textContent || '').trim();
          const firstLine = raw.split('\n')[0].trim();
          if (firstLine && !isBadCandidate(firstLine) && !isMemberList(firstLine)) {
            return firstLine;
          }
        }
      }

      // Varredura geométrica nos elementos de texto do cabeçalho
      const candidateList = [];
      const allSpans = Array.from(mainHeader.querySelectorAll('span, div, h2, h3'));
      for (const s of allSpans) {
        if (s.closest('#fiscalizacampo-panel') || s.closest('#fac-global-stop-bar') || s.closest('#fiscalizacampo-floating-btn')) continue;
        if (s.closest('button:not([role="button"]), [data-testid="menu"], [data-testid="search"], [data-testid="voice-call"], [data-testid="chat-avatar"]')) continue;

        const raw = (s.getAttribute('title') || (s.children.length === 0 ? s.innerText || s.textContent : '')).trim();
        if (!raw || isBadCandidate(raw)) continue;

        const firstLine = raw.split('\n')[0].trim();
        if (!firstLine || isBadCandidate(firstLine)) continue;

        const rect = s.getBoundingClientRect();
        if (rect.width === 0 || rect.height === 0) continue;

        const isMem = isMemberList(firstLine);
        const style = window.getComputedStyle(s);
        const fontSize = parseFloat(style.fontSize) || 14;

        candidateList.push({
          text: firstLine,
          top: rect.top,
          fontSize,
          isMem,
        });
      }

      if (candidateList.length > 0) {
        // Prioriza não-membros, maior tamanho de fonte e linha do topo
        candidateList.sort((a, b) => {
          if (a.isMem !== b.isMem) return a.isMem ? 1 : -1;
          if (Math.abs(b.fontSize - a.fontSize) > 1) return b.fontSize - a.fontSize;
          return a.top - b.top;
        });

        if (!candidateList[0].isMem) {
          return candidateList[0].text;
        }
      }
    }

    // 2. Modelo de dados interno oficial do WhatsApp (WWebJS / Store)
    try {
      const waCollections = getWAWebModule('WAWebCollections') || window.Store;
      const activeChat = waCollections?.Chat?.getActive ? waCollections.Chat.getActive() : waCollections?.Chat?.models?.find((c) => c.active);
      const internalName = activeChat?.name || activeChat?.formattedTitle || activeChat?.contact?.name || activeChat?.contact?.pushname;
      if (internalName && typeof internalName === 'string' && !isBadCandidate(internalName) && !isMemberList(internalName)) {
        return internalName.trim();
      }
    } catch (e) {}

    // 3. Título limpo da aba do navegador (document.title)
    if (document.title && !document.title.toLowerCase().startsWith('whatsapp')) {
      const cleanDocTitle = document.title.replace(/^\(\d+\)\s*/, '').replace(/\s*\|\s*WhatsApp$/i, '').trim();
      if (cleanDocTitle && !isBadCandidate(cleanDocTitle) && !isMemberList(cleanDocTitle)) {
        return cleanDocTitle;
      }
    }

    // 4. Item da lista lateral com conversa ativa estrita (excluindo cabeçalhos e status)
    try {
      const activeSidebarItem = document.querySelector(
        '#pane-side div[aria-selected="true"]:not([data-testid="status-v3-header"]), #pane-side div[data-testid="cell-frame-container"].selected, #pane-side div[role="listitem"][aria-selected="true"]'
      );
      if (activeSidebarItem) {
        const titleEl = activeSidebarItem.querySelector('span[title], span[dir="auto"], span._ao3e');
        if (titleEl) {
          const raw = (titleEl.getAttribute('title') || titleEl.innerText || titleEl.textContent || '').trim();
          const line = raw.split('\n')[0].trim();
          if (line && !isBadCandidate(line) && !isMemberList(line)) {
            return line;
          }
        }
      }
    } catch (e) {}

    return 'Conversa_WhatsApp';
  }

  function updateActiveGroupName() {
    const input = document.getElementById('fac-active-group-name');
    if (input && (input.value === 'Detectando conversa...' || input.value === 'Conversa_WhatsApp')) {
      input.value = getActiveGroupName();
    }
  }

  function getPrefixesList() {
    return ['BSO', 'SER', 'CON', 'PAV', 'ROC', 'DRE', 'CAP', 'TAP', 'OAE'];
  }

  function findScrollContainer() {
    const candidates = [
      document.querySelector('div[data-tab="8"]'),
      document.querySelector('#main div[data-tab="8"]'),
      document.querySelector('div[data-testid="conversation-panel-messages"]'),
      document.querySelector('#main div[tabindex="-1"]'),
      document.querySelector('#main [role="region"]'),
      document.querySelector('#main .copyable-area > div[tabindex="0"]'),
      document.querySelector('#main div[class*="copyable-area"]'),
    ];

    for (const c of candidates) {
      if (c && c.scrollHeight > c.clientHeight && c.querySelector('.message-in, .message-out, div[data-testid^="msg-"], div[data-id]')) {
        return c;
      }
    }

    const main = document.querySelector('#main');
    if (main) {
      const allDivs = main.querySelectorAll('div');
      for (const div of allDivs) {
        const style = window.getComputedStyle(div);
        if ((style.overflowY === 'scroll' || style.overflowY === 'auto') && div.scrollHeight > div.clientHeight + 40) {
          if (div.querySelector('.message-in, .message-out, div[data-testid^="msg-"], div[data-id]')) {
            return div;
          }
        }
      }
    }

    return null;
  }

  function findGalleryScrollContainer() {
    const rightDrawer = document.querySelector('div[data-testid="chat-info-drawer"], [role="region"], div[tabindex="-1"]');
    if (rightDrawer) {
      const scrollables = Array.from(rightDrawer.querySelectorAll('div')).filter((div) => {
        const style = window.getComputedStyle(div);
        return (style.overflowY === 'scroll' || style.overflowY === 'auto') && div.scrollHeight > div.clientHeight + 40;
      });
      const withImg = scrollables.find((s) => s.querySelector('img'));
      if (withImg) return withImg;
    }

    const allScrollables = Array.from(document.querySelectorAll('div')).filter((div) => {
      const style = window.getComputedStyle(div);
      return (style.overflowY === 'scroll' || style.overflowY === 'auto') && div.scrollHeight > div.clientHeight + 80 && div.querySelectorAll('img').length > 3;
    });

    return allScrollables[0] || null;
  }

  function clickOlderMessagesBanner() {
    const main = document.querySelector('#main');
    if (!main) return false;

    const pattern = /clique\s+aqui|mais\s+mensagens|mensagens\s+mais\s+antigas|carregar\s+mais|mensagens\s+anteriores|load\s+older|older\s+messages|ver\s+mais|mensagens\s+antigas|sincronizar\s+mais|pesquisar\s+no\s+servidor/i;

    const clickables = Array.from(main.querySelectorAll('button, div[role="button"], span[role="button"], div[tabindex="0"], a'));
    for (const el of clickables) {
      const text = (el.innerText || el.textContent || '').trim();
      if (pattern.test(text)) {
        el.click();
        return true;
      }
    }
    return false;
  }

  const monthsMap = {
    janeiro: 0, jan: 0,
    fevereiro: 1, fev: 1,
    março: 2, marco: 2, mar: 2,
    abril: 3, abr: 3,
    maio: 4, mai: 4,
    junho: 5, jun: 5,
    julho: 6, jul: 6,
    agosto: 7, ago: 7,
    setembro: 8, set: 8,
    outubro: 9, out: 9,
    novembro: 10, nov: 10,
    dezembro: 11, dez: 11
  };

  const weekdaysMap = {
    'domingo': 0, 'sunday': 0,
    'segunda-feira': 1, 'segunda': 1, 'monday': 1,
    'terça-feira': 2, 'terca-feira': 2, 'terça': 2, 'terca': 2, 'tuesday': 2,
    'quarta-feira': 3, 'quarta': 3, 'wednesday': 3,
    'quinta-feira': 4, 'quinta': 4, 'thursday': 4,
    'sexta-feira': 5, 'sexta': 5, 'friday': 5,
    'sábado': 6, 'sabado': 6, 'saturday': 6,
  };

  function getDateForWeekday(targetDayIndex) {
    const now = new Date();
    const currentDayIndex = now.getDay();
    let diff = currentDayIndex - targetDayIndex;
    if (diff <= 0) {
      diff += 7;
    }
    return new Date(now.getFullYear(), now.getMonth(), now.getDate() - diff, 12, 0, 0);
  }

  /**
   * Analisa estritamente textos de divisores de data do WhatsApp
   * (NUNCA chamado em frases longas ou no corpo de conversas)
   */
  function parseDateDividerText(text) {
    if (!text) return null;
    const str = text.trim().toLowerCase().replace(/[\u200B-\u200D\uFEFF]/g, '');
    if (str.length < 3 || str.length > 40) return null;

    if (str === 'hoje' || str === 'today') {
      const now = new Date();
      return new Date(now.getFullYear(), now.getMonth(), now.getDate(), 12, 0, 0);
    }

    if (str === 'ontem' || str === 'yesterday') {
      const now = new Date();
      return new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1, 12, 0, 0);
    }

    if (weekdaysMap.hasOwnProperty(str)) {
      return getDateForWeekday(weekdaysMap[str]);
    }

    const writtenMatch = str.match(/^(\d{1,2})\s+de\s+([a-zç]+)\.?\s+de\s+(\d{4})$/i);
    if (writtenMatch) {
      const day = parseInt(writtenMatch[1], 10);
      const mName = writtenMatch[2].replace('.', '');
      const month = monthsMap[mName];
      const year = parseInt(writtenMatch[3], 10);
      if (month !== undefined && !isNaN(day) && !isNaN(year) && year >= 2020 && year <= 2035) {
        return new Date(year, month, day, 12, 0, 0);
      }
    }

    const writtenNoYearMatch = str.match(/^(\d{1,2})\s+de\s+([a-zç]+)\.?$/i);
    if (writtenNoYearMatch) {
      const day = parseInt(writtenNoYearMatch[1], 10);
      const mName = writtenNoYearMatch[2].replace('.', '');
      const month = monthsMap[mName];
      if (month !== undefined && !isNaN(day)) {
        const now = new Date();
        let year = now.getFullYear();
        if (month > now.getMonth()) {
          year -= 1;
        }
        return new Date(year, month, day, 12, 0, 0);
      }
    }

    const slashMatch = str.match(/^(\d{1,2})[\/\-\.](\d{1,2})[\/\-\.](\d{2}|\d{4})$/);
    if (slashMatch) {
      let day = parseInt(slashMatch[1], 10);
      let month = parseInt(slashMatch[2], 10) - 1;
      let rawYear = parseInt(slashMatch[3], 10);
      let year = slashMatch[3].length === 2 ? 2000 + rawYear : rawYear;

      if (month > 11 && day <= 12) {
        const temp = day - 1;
        day = month + 1;
        month = temp;
      }

      if (month >= 0 && month <= 11 && day >= 1 && day <= 31 && year >= 2020 && year <= 2035) {
        return new Date(year, month, day, 12, 0, 0);
      }
    }

    return null;
  }

  /**
   * Extrai a data exata embutida no atributo nativo do WhatsApp [HH:MM, DD/MM/AAAA]
   */
  function extractDateFromPrePlainText(pre) {
    if (!pre) return null;
    const str = pre.replace(/[\u200B-\u200D\uFEFF]/g, '').trim();

    const bracketMatch = str.match(/\[(?:.*?,?\s*)?(\d{1,2})[\/\-\.](\d{1,2})[\/\-\.](\d{2,4})(?:.*?)?\]/);
    if (bracketMatch) {
      let p1 = parseInt(bracketMatch[1], 10);
      let p2 = parseInt(bracketMatch[2], 10);
      let yr = parseInt(bracketMatch[3], 10);
      if (yr < 100) yr += 2000;

      let day = p1;
      let month = p2 - 1;

      if (p2 > 12 && p1 <= 12) {
        day = p2;
        month = p1 - 1;
      }

      if (month >= 0 && month <= 11 && day >= 1 && day <= 31 && yr >= 2020 && yr <= 2035) {
        return new Date(yr, month, day, 12, 0, 0);
      }
    }

    const writtenMatch = str.match(/\[(?:.*?,?\s*)?(\d{1,2})\s+de\s+([a-zç]+)\.?\s+de\s+(\d{4})(?:.*?)?\]/i);
    if (writtenMatch) {
      const day = parseInt(writtenMatch[1], 10);
      const mName = writtenMatch[2].replace('.', '').toLowerCase();
      const month = monthsMap[mName];
      const yr = parseInt(writtenMatch[3], 10);
      if (month !== undefined && !isNaN(day) && !isNaN(yr) && yr >= 2020 && yr <= 2035) {
        return new Date(yr, month, day, 12, 0, 0);
      }
    }

    return null;
  }

  /**
   * Analisa datas no cabeçalho do visualizador de mídia do WhatsApp Web (ex: "Nerias\n14/09/2026 às 17:19")
   */
  function parseViewerHeaderDate(text) {
    if (!text) return null;
    const str = text.replace(/[\u200B-\u200D\uFEFF]/g, ' ').trim();

    // 1. Padrão estrito de data do WhatsApp: DD/MM/AAAA ou DD/MM/AA (ex: "14/09/2026 às 17:19" ou "14/09/26")
    const matchSlash = str.match(/\b(\d{1,2})\/(\d{1,2})\/(\d{2,4})\b/);
    if (matchSlash) {
      const day = parseInt(matchSlash[1], 10);
      const month = parseInt(matchSlash[2], 10) - 1;
      let year = parseInt(matchSlash[3], 10);
      if (year < 100) year += 2000;
      if (month >= 0 && month <= 11 && day >= 1 && day <= 31 && year >= 2020 && year <= 2035) {
        return new Date(year, month, day, 12, 0, 0);
      }
    }

    // 2. "Hoje às ..." ou "Hoje, ..."
    if (/\bhoje\b/i.test(str)) {
      const now = new Date();
      return new Date(now.getFullYear(), now.getMonth(), now.getDate(), 12, 0, 0);
    }

    // 3. "Ontem às ..." ou "Ontem, ..."
    if (/\bontem\b/i.test(str)) {
      const now = new Date();
      return new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1, 12, 0, 0);
    }

    // 4. "14 de setembro de 2026"
    const writtenMatch = str.match(/(\d{1,2})\s+de\s+([a-zç]+)\.?\s+de\s+(\d{4})/i);
    if (writtenMatch) {
      const day = parseInt(writtenMatch[1], 10);
      const mStr = writtenMatch[2].toLowerCase();
      const year = parseInt(writtenMatch[3], 10);
      if (monthsMap.hasOwnProperty(mStr) && year >= 2020 && year <= 2035) {
        return new Date(year, monthsMap[mStr], day, 12, 0, 0);
      }
    }

    // 5. Dia da semana oficial do WhatsApp (ex: "segunda-feira às 14:20")
    for (const [wName, wIdx] of Object.entries(weekdaysMap)) {
      const regex = new RegExp(`\\b${wName}\\b`, 'i');
      if (regex.test(str)) {
        return getDateForWeekday(wIdx);
      }
    }

    return null;
  }

  /**
   * Extrai a data e o remetente estritamente do cabeçalho nativo do visualizador de fotos do WhatsApp
   * (NUNCA lê elementos do painel da extensão, garantindo precisão absoluta)
   */
  function getStrictViewerDateAndAuthor(mediaViewer) {
    if (!mediaViewer) return { date: null, author: '', rawHeader: '' };

    const headerCandidates = [
      mediaViewer.querySelector('header'),
      mediaViewer.querySelector('div[data-testid="media-viewer-header"]'),
      document.querySelector('div[data-testid="media-viewer"] header'),
      document.querySelector('div[data-testid="lightbox-wrapper"] header'),
      document.querySelector('div[data-testid="popup-media-viewer"] header'),
    ].filter(Boolean);

    for (const h of headerCandidates) {
      if (h.closest('#fiscalizacampo-panel') || h.closest('#fac-global-stop-bar') || h.closest('#fiscalizacampo-floating-btn')) continue;
      const text = (h.innerText || '').trim();
      const date = parseViewerHeaderDate(text);
      if (date) {
        const lines = text.split('\n').map((l) => l.trim()).filter(Boolean);
        const author = lines.length > 1 ? lines[0] : '';
        return { date, author, rawHeader: text };
      }
    }

    // Busca secundária nas spans do topo esquerdo da tela (excluindo extensão)
    const topSpans = Array.from(document.querySelectorAll('span, div')).filter((el) => {
      if (el.closest('#fiscalizacampo-panel') || el.closest('#fac-global-stop-bar') || el.closest('#fiscalizacampo-floating-btn')) return false;
      const rect = el.getBoundingClientRect();
      return rect.top >= 0 && rect.top <= 80 && rect.left >= 0 && rect.left <= 420 && el.children.length === 0;
    });

    for (const span of topSpans) {
      const txt = (span.innerText || span.textContent || '').trim();
      const date = parseViewerHeaderDate(txt);
      if (date) {
        return { date, author: '', rawHeader: txt };
      }
    }

    return { date: null, author: '', rawHeader: '' };
  }

  /**
   * Localiza o divisor de data real do chat que antecede a bolha de mensagem no DOM
   */
  function getPrecedingDateDivider(bubbleEl) {
    const mainChat = document.querySelector('#main');
    if (!mainChat || !bubbleEl) return null;

    const candidates = Array.from(
      mainChat.querySelectorAll(
        'div[data-testid="chat-history-date-divider"], div[data-testid="date-badge"], span[data-testid="date-badge"], ' +
        'div[role="heading"], div[class*="date-divider"], div[class*="date-badge"], div[class*="_amlo"], div[class*="_ao3e"]'
      )
    );

    let nearestPrecedingDate = null;

    for (const c of candidates) {
      // Divisores reais nunca ficam dentro de bolhas de mensagens
      if (c.closest('.message-in, .message-out, div[data-testid^="msg-"]')) continue;

      const txt = (c.innerText || c.textContent || '').trim();
      const parsed = parseDateDividerText(txt);
      if (!parsed) continue;

      const pos = c.compareDocumentPosition(bubbleEl);
      if (pos & Node.DOCUMENT_POSITION_FOLLOWING) {
        nearestPrecedingDate = parsed;
      }
    }

    return nearestPrecedingDate;
  }

  function extractDateFromBubbleAndDOM(bubbleEl, text) {
    if (bubbleEl) {
      // 1. data-pre-plain-text diretamente no elemento ou ancestrais próximos
      let curr = bubbleEl;
      for (let i = 0; i < 6 && curr; i++) {
        const pre = curr.getAttribute('data-pre-plain-text');
        if (pre) {
          const parsed = extractDateFromPrePlainText(pre);
          if (parsed) return parsed;
        }
        curr = curr.parentElement;
      }

      // 2. data-pre-plain-text em elemento filho
      const childWithPre = bubbleEl.querySelector('[data-pre-plain-text]');
      if (childWithPre) {
        const parsed = extractDateFromPrePlainText(childWithPre.getAttribute('data-pre-plain-text'));
        if (parsed) return parsed;
      }

      // 3. Checa mensagens irmãs adjacentes imediatas (mesmo pacote/bloco de envio)
      let prevSibling = bubbleEl.previousElementSibling;
      for (let i = 0; i < 3 && prevSibling; i++) {
        const siblingPre = prevSibling.getAttribute('data-pre-plain-text') || prevSibling.querySelector('[data-pre-plain-text]')?.getAttribute('data-pre-plain-text');
        if (siblingPre) {
          const parsed = extractDateFromPrePlainText(siblingPre);
          if (parsed) return parsed;
        }
        prevSibling = prevSibling.previousElementSibling;
      }

      // 4. Divisor de data real que precede a mensagem no histórico do WhatsApp
      const dividerDate = getPrecedingDateDivider(bubbleEl);
      if (dividerDate) return dividerDate;
    }

    // 5. Se houver data explícita formatada em DD/MM/AAAA no texto da legenda
    if (text) {
      const explicitDateMatch = text.match(/\b(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{2,4})\b/);
      if (explicitDateMatch) {
        let d = parseInt(explicitDateMatch[1], 10);
        let mo = parseInt(explicitDateMatch[2], 10) - 1;
        let yr = parseInt(explicitDateMatch[3], 10);
        if (yr < 100) yr += 2000;
        if (mo >= 0 && mo <= 11 && d >= 1 && d <= 31 && yr >= 2020 && yr <= 2035) {
          return new Date(yr, mo, d, 12, 0, 0);
        }
      }
    }

    return null;
  }

  function findEarliestVisibleDate() {
    const mainChat = document.querySelector('#main');
    if (!mainChat) return null;

    let earliestFound = null;

    // 1. Divisores reais visíveis no chat
    const realBadges = Array.from(
      mainChat.querySelectorAll(
        'div[data-testid="chat-history-date-divider"], div[data-testid="date-badge"], span[data-testid="date-badge"], ' +
        'div[role="heading"], div[class*="date-divider"], div[class*="date-badge"]'
      )
    );

    for (const badge of realBadges) {
      if (badge.closest('.message-in, .message-out, div[data-testid^="msg-"]')) continue;
      const txt = (badge.innerText || badge.textContent || '').trim();
      const d = parseDateDividerText(txt);
      if (d && (!earliestFound || d < earliestFound)) {
        earliestFound = d;
      }
    }

    // 2. Mensagens do topo visível com data-pre-plain-text
    const messages = Array.from(mainChat.querySelectorAll('.message-in, .message-out, div[data-testid^="msg-"]'));
    const topMessages = messages
      .map((el) => ({ el, top: el.getBoundingClientRect().top }))
      .filter((item) => item.top >= -200 && item.top < 600)
      .sort((a, b) => a.top - b.top)
      .slice(0, 20);

    for (const { el } of topMessages) {
      const pre = el.getAttribute('data-pre-plain-text') || el.querySelector('[data-pre-plain-text]')?.getAttribute('data-pre-plain-text');
      if (pre) {
        const d = extractDateFromPrePlainText(pre);
        if (d && (!earliestFound || d < earliestFound)) {
          earliestFound = d;
        }
      }
    }

    return earliestFound;
  }

  function extractMetadataFromText(text, bubbleEl, prefixes) {
    let item = 'GERAL';
    let km = '';
    let rodovia = '';
    let empresa = '';
    let equipe = '';
    let areaFrente = '';

    for (const p of prefixes) {
      const regexNum = new RegExp(`\\b(${p})[\\s\\-_]*0*(\\d+)`, 'i');
      const m = text.match(regexNum);
      if (m) {
        const num = parseInt(m[2], 10);
        item = `${m[1].toUpperCase()}${String(num).padStart(2, '0')}`;
        areaFrente = item;
        break;
      }
      const regexWord = new RegExp(`\\b(${p})\\b`, 'i');
      if (regexWord.test(text)) {
        item = p.toUpperCase();
        areaFrente = item;
        break;
      }
    }

    const kmMatch = text.match(/km\s*(\d+[\d.,]*\+?\d*)/i);
    if (kmMatch) km = kmMatch[0].toUpperCase();

    const rodMatch = text.match(/\b(SP|BR|MG|RJ|PR|SC|RS)[\s\-]?\d{2,3}\b/i);
    if (rodMatch) rodovia = rodMatch[0].toUpperCase().replace(/\s+/, '-');

    const empMatch = text.match(/(?:empresa|empreiteira|contratada)[:\s]+([^\n,]+)/i);
    if (empMatch) empresa = empMatch[1].trim();

    const eqMatch = text.match(/(?:equipe|turma|frente)[:\s]+([^\n,]+)/i);
    if (eqMatch) equipe = eqMatch[1].trim();

    const detectedDate = extractDateFromBubbleAndDOM(bubbleEl, text);

    let dateKey = '';
    let dateStr = '';

    if (detectedDate) {
      const yyyy = detectedDate.getFullYear();
      const mm = String(detectedDate.getMonth() + 1).padStart(2, '0');
      const dd = String(detectedDate.getDate()).padStart(2, '0');
      dateKey = `${yyyy}${mm}${dd}`;
      dateStr = `${dd}/${mm}/${yyyy}`;
    }

    return {
      item,
      areaFrente: areaFrente || 'GERAL',
      km,
      rodovia,
      empresa,
      equipe,
      dateKey,
      dateStr,
      dateObj: detectedDate,
    };
  }

  function triggerMediaDownloads() {
    const mainChat = document.querySelector('#main');
    if (!mainChat) return 0;

    const downloadCandidates = Array.from(
      mainChat.querySelectorAll(
        'button[aria-label*="Baixar" i], button[aria-label*="Download" i], button[aria-label*="Descargar" i], ' +
        'div[role="button"][aria-label*="Baixar" i], div[role="button"][aria-label*="Download" i], ' +
        'div[data-testid="media-download-button"], button[data-testid="download-button"], button[data-testid="button-download"], ' +
        'span[data-icon="download"], span[data-icon="arrow-down"], span[data-icon="refresh-large"]'
      )
    );

    let triggered = 0;
    for (const btn of downloadCandidates) {
      if (btn.id === 'fac-close-btn' || btn.closest('#fiscalizacampo-panel') || btn.closest('#fac-global-stop-bar')) continue;

      const clickable = btn.tagName === 'SPAN' ? btn.closest('button, div[role="button"]') || btn : btn;
      const attrKey = `data-fac-dl-${currentScanRunId}`;
      if (clickable && !clickable.hasAttribute(attrKey)) {
        clickable.setAttribute(attrKey, 'true');
        try {
          clickable.click();
          triggered++;
        } catch (e) {}
      }
    }
    return triggered;
  }

  /**
   * Captura foto com resolução máxima abrindo o visualizador nativo se necessário
   */
  async function captureRealHdFromViewer(imgOrClickable) {
    if (!imgOrClickable || shouldStopScanning) return null;
    try {
      imgOrClickable.click();

      const viewerImg = await waitForCondition(() => {
        const viewer = document.querySelector('div[data-testid="media-viewer"], div[data-testid="lightbox-wrapper"]');
        if (!viewer) return null;
        const img = viewer.querySelector('img[src^="blob:"]') || viewer.querySelector('img[src]');
        if (img && img.src && img.complete && (img.naturalWidth > 0 || img.src.startsWith('blob:'))) {
          return img;
        }
        return null;
      }, { timeoutMs: 1600, intervalMs: 60 });

      if (viewerImg && viewerImg.src) {
        const blob = await fetchBlobDirectly(viewerImg.src);
        if (blob && blob.size >= 600) {
          const dims = await getImageDimensionsFromBlob(blob);
          const isRealHd = (dims.width >= 600 || dims.height >= 600 || blob.size >= 40000);
          dismissUnwantedModals();
          return {
            blob,
            isHd: isRealHd,
            isThumbnail: !isRealHd,
            resolutionCategory: isRealHd ? 'Alta Resolução (Visualizador)' : 'Média Resolução (Visualizador)',
            width: dims.width,
            height: dims.height,
            size: blob.size,
          };
        }
      }
      dismissUnwantedModals();
    } catch (e) {
      dismissUnwantedModals();
    }
    return null;
  }

  /**
   * PONTO 1: ENUMERAÇÃO DE ÁLBUNS COM AVISO EXPLÍCITO DE TETO DE SEGURANÇA
   * Se um álbum atingir MAX_ALBUM_PHOTOS sem que os controles de navegação
   * indiquem o fim natural, registra alerta explícito e não o trata como concluído.
   * Suporta todos os álbuns: com +N, álbuns de 2 a 4 fotos e grades múltiplas.
   */
  async function expandVisibleAlbums(prefixes) {
    const mainChat = document.querySelector('#main');
    if (!mainChat || shouldStopScanning) return 0;

    const runAttr = `data-fac-album-${currentScanRunId}`;
    let expanded = 0;

    // Detecta bolhas de mensagem no chat
    const bubbles = Array.from(mainChat.querySelectorAll('.message-in, .message-out, div[data-testid^="msg-"]'));

    for (const bubble of bubbles) {
      if (shouldStopScanning) break;
      if (bubble.hasAttribute(runAttr) || bubble.hasAttribute('data-fac-album-processed')) continue;

      // Critérios de identificação de Álbum:
      // 1. Overlay com badge "+N" (5+ fotos)
      // 2. Elemento com data-testid="album" ou classe de álbum
      // 3. Duas ou mais imagens dentro da mesma mensagem
      const hasPlusBadge = Array.from(bubble.querySelectorAll('span, div')).some((el) => {
        const txt = (el.textContent || '').trim();
        return /^\+\d+$/.test(txt);
      });
      const hasAlbumContainer = Boolean(bubble.querySelector('div[data-testid="album"], div[class*="album"]'));
      const imgCount = bubble.querySelectorAll('img').length;

      if (!hasPlusBadge && !hasAlbumContainer && imgCount < 2) {
        continue;
      }

      // Marca o álbum para esta execução para nunca reprocessar nem duplicar
      bubble.setAttribute(runAttr, 'true');
      bubble.setAttribute('data-fac-album-processed', 'true');

      const bubbleText = (bubble.innerText || '').trim();
      const meta = extractMetadataFromText(bubbleText, bubble, prefixes);

      // Localiza o elemento clicável do álbum
      const plusBadgeEl = Array.from(bubble.querySelectorAll('span, div')).find((el) => /^\+\d+$/.test((el.textContent || '').trim()));
      const clickable =
        plusBadgeEl?.closest('div[role="button"], button') ||
        plusBadgeEl ||
        bubble.querySelector('div[data-testid="album"] div[role="button"], div[role="button"]:has(img), img') ||
        bubble.querySelector('img') ||
        bubble;

      try {
        clickable.click();

        const mediaViewer = await waitForCondition(() => {
          return document.querySelector('div[data-testid="media-viewer"], div[data-testid="lightbox-wrapper"]');
        }, { timeoutMs: 2500, intervalMs: 60 });

        if (mediaViewer) {
          const visitedViewerMedia = new Set();
          let consecutiveUnchangedCount = 0;
          let albumStep = 0;
          let reachedNaturalEnd = false;
          const albumCapturedKeys = [];

          while (!shouldStopScanning && albumStep < MAX_ALBUM_PHOTOS) {
            albumStep++;

            const currentImg = await waitForCondition(() => {
              const img = mediaViewer.querySelector('img[src^="blob:"]') || mediaViewer.querySelector('img[src]');
              if (img && img.src && img.complete && (img.naturalWidth > 0 || img.src.startsWith('blob:'))) {
                return img;
              }
              return null;
            }, { timeoutMs: 2200, intervalMs: 60 });

            if (!currentImg || !currentImg.src) {
              reachedNaturalEnd = true;
              break;
            }

            const mediaSrc = currentImg.src;

            if (visitedViewerMedia.has(mediaSrc)) {
              consecutiveUnchangedCount++;
              if (consecutiveUnchangedCount >= 2) {
                // A imagem não mudou após tentativas: fim natural comprovado
                reachedNaturalEnd = true;
                break;
              }
            } else {
              consecutiveUnchangedCount = 0;
              visitedViewerMedia.add(mediaSrc);

              // 1. Tenta extração direta via WWebJS.resolveMediaBlob se houver ID de mensagem no visualizador
              let blob = null;
              let dims = { width: 0, height: 0 };
              let isRealHd = false;
              let resolutionCategory = 'Alta Resolução (Visualizador)';

              const viewerMsgId =
                currentImg.getAttribute('data-id') ||
                currentImg.closest('[data-id]')?.getAttribute('data-id') ||
                mediaViewer.querySelector('[data-id]')?.getAttribute('data-id');

              if (viewerMsgId) {
                const directMedia = await requestResolveMedia(viewerMsgId);
                if (directMedia && directMedia.blob && directMedia.blob.size >= 600) {
                  blob = directMedia.blob;
                  dims = await getImageDimensionsFromBlob(blob);
                  isRealHd = (dims.width >= 600 || dims.height >= 600 || blob.size >= 40000);
                  resolutionCategory = 'Alta Resolução (Extração Direta WhatsApp)';
                }
              }

              // 2. Fallback: fetch direto da URL blob do visualizador
              if (!blob) {
                blob = await fetchBlobDirectly(mediaSrc);
                if (blob && blob.size >= 600) {
                  dims = await getImageDimensionsFromBlob(blob);
                  isRealHd = (dims.width >= 600 || dims.height >= 600 || blob.size >= 40000);
                  resolutionCategory = isRealHd ? 'Alta Resolução (Visualizador)' : 'Média Resolução (Visualizador)';
                }
              }

              if (blob && blob.size >= 600) {
                const albumKey = `album_img_${mediaSrc.replace(/^blob:[^/]+\//, '').slice(-32)}`;
                albumCapturedKeys.push(albumKey);

                if (!photoAccumulator.has(albumKey)) {
                  // Salva o blob no IndexedDB para não inflar a memória
                  await TempBlobStorage.store(albumKey, blob);

                  photoAccumulator.set(albumKey, {
                    key: albumKey,
                    meta,
                    rawText: bubbleText || 'Foto de Álbum Expandido',
                    isHd: isRealHd,
                    isThumbnail: !isRealHd,
                    resolutionCategory,
                    size: blob.size,
                    width: dims.width,
                    height: dims.height,
                    timestamp: Date.now(),
                    cappedAlbum: false,
                    blob: blob,
                  });
                  if (meta?.dateStr) {
                    updateLastPhotoDateDisplay(meta.dateStr);
                  }
                  expanded++;
                }
              }
            }

            // Verifica o botão de avançar na interface
            const nextBtn = mediaViewer.querySelector(
              'div[data-testid="media-viewer-next"], button[data-testid="media-viewer-next"], div[role="button"][aria-label*="Next" i], button[aria-label*="Next" i], div[role="button"][aria-label*="Próxim" i], button[aria-label*="Próxim" i]'
            ) || mediaViewer.querySelector('span[data-icon="chevron-right"]')?.closest('div[role="button"], button');

            if (nextBtn) {
              const isDisabled = nextBtn.hasAttribute('disabled') || nextBtn.getAttribute('aria-disabled') === 'true';
              if (isDisabled) {
                reachedNaturalEnd = true;
                break;
              }
              nextBtn.click();
            } else {
              window.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowRight', code: 'ArrowRight', keyCode: 39, bubbles: true }));
            }

            // Aguarda a imagem mudar com timeout de 2500ms
            const changed = await waitForCondition(() => {
              const img = mediaViewer.querySelector('img[src^="blob:"]') || mediaViewer.querySelector('img[src]');
              return img && img.src && img.src !== mediaSrc;
            }, { timeoutMs: 2500, intervalMs: 60 });

            if (!changed) {
              // Tenta mais um clique caso a rede ou WhatsApp tenha engasgado
              if (nextBtn && !nextBtn.hasAttribute('disabled') && nextBtn.getAttribute('aria-disabled') !== 'true') {
                nextBtn.click();
              } else {
                window.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowRight', code: 'ArrowRight', keyCode: 39, bubbles: true }));
              }
              await waitForCondition(() => {
                const img = mediaViewer.querySelector('img[src^="blob:"]') || mediaViewer.querySelector('img[src]');
                return img && img.src && img.src !== mediaSrc;
              }, { timeoutMs: 1500, intervalMs: 60 });
            }
          }

          // Se atingiu o teto sem confirmação de fim natural, marca como INTERROMPIDO PELO TETO
          if (albumStep >= MAX_ALBUM_PHOTOS && !reachedNaturalEnd) {
            const warningInfo = {
              title: bubbleText.slice(0, 45) || 'Álbum',
              captured: albumStep,
              limit: MAX_ALBUM_PHOTOS,
            };
            albumCeilingWarnings.push(warningInfo);
            console.warn(`[Conserva_Fotos] ATENÇÃO: Álbum com mais de ${MAX_ALBUM_PHOTOS} fotos atingiu o teto de segurança e foi interrompido.`, warningInfo);

            for (const k of albumCapturedKeys) {
              const rec = photoAccumulator.get(k);
              if (rec) rec.cappedAlbum = true;
            }

            const statusText = document.getElementById('fac-status-text');
            if (statusText) {
              statusText.textContent = `⚠️ Atenção: Álbum com +${MAX_ALBUM_PHOTOS} fotos atingiu o limite e foi interrompido por segurança.`;
            }
          }

          dismissUnwantedModals();
        }
      } catch (e) {
        dismissUnwantedModals();
      }
    }

    return expanded;
  }

  /**
   * Coleta fotos individuais das bolhas visíveis no Chat
   * (Pula bolhas de álbuns já processadas pelo visualizador para garantir alta resolução e zero duplicatas)
   */
  async function collectVisiblePhotos(prefixes) {
    dismissUnwantedModals();
    const triggered = triggerMediaDownloads();
    if (triggered > 0) {
      // Breve pausa para o WhatsApp iniciar o download das mídias
      await interruptibleSleep(400);
    }

    const mainChat = document.querySelector('#main');
    if (!mainChat) return 0;

    const bubbles = Array.from(
      mainChat.querySelectorAll('.message-in, .message-out, div[data-testid^="msg-"], div[data-id]')
    );

    let newlyAdded = 0;

    for (const bubble of bubbles) {
      if (shouldStopScanning) break;

      // Pula álbuns já expandidos para evitar capturar miniaturas duplicadas
      if (bubble.hasAttribute('data-fac-album-processed') || bubble.getAttribute(`data-fac-album-${currentScanRunId}`)) {
        continue;
      }
      // Se for álbum (container de álbum ou 2+ fotos), será processado por expandVisibleAlbums
      if (bubble.querySelector('div[data-testid="album"], div[class*="album"]') || bubble.querySelectorAll('img').length >= 2) {
        continue;
      }

      const bubbleText = (bubble.innerText || '').trim();
      const preText = bubble.getAttribute('data-pre-plain-text') || bubble.querySelector('[data-pre-plain-text]')?.getAttribute('data-pre-plain-text') || '';
      const dataId = bubble.getAttribute('data-id') || bubble.closest('[data-id]')?.getAttribute('data-id') || '';

      const imgElements = Array.from(bubble.querySelectorAll('img')).filter((img) => {
        const src = img.src || '';
        if (img.closest('div[data-testid="chat-avatar"], div[data-testid="avatar"], .avatar')) return false;
        return (
          src.startsWith('blob:') ||
          src.startsWith('data:image') ||
          src.includes('.whatsapp.net') ||
          img.closest('div[data-testid="image-thumb"]') ||
          img.closest('.message-in, .message-out')
        );
      });

      if (imgElements.length === 0) continue;

      const meta = extractMetadataFromText(bubbleText, bubble, prefixes);
      const stableMsgId = dataId || preText || `msg_${meta.dateKey || 'single'}_${Math.round(bubble.getBoundingClientRect().top)}`;

      for (let idx = 0; idx < imgElements.length; idx++) {
        if (shouldStopScanning) break;
        const img = imgElements[idx];
        const photoKey = `${stableMsgId}_slot_${idx}`;

        // Se a imagem ainda estiver carregando, aguarda completar
        if (!img.complete && img.src) {
          await waitForCondition(() => img.complete && img.naturalWidth > 0, { timeoutMs: 1400, intervalMs: 50 });
        }

        const isBlob = img.src && img.src.startsWith('blob:');
        let blob = null;
        let isRealHd = false;
        let resolutionCategory = 'Resolução não verificada / Miniatura';
        let dims = { width: img.naturalWidth || 0, height: img.naturalHeight || 0 };

        // 1. TENTATIVA PRIORITÁRIA: Extração Direta via WWebJS.resolveMediaBlob (whatsapp-web.js)
        const targetMsgId = img.getAttribute('data-id') || img.closest('[data-id]')?.getAttribute('data-id') || dataId;
        if (targetMsgId) {
          const directMedia = await requestResolveMedia(targetMsgId);
          if (directMedia && directMedia.blob && directMedia.blob.size >= 600) {
            blob = directMedia.blob;
            dims = await getImageDimensionsFromBlob(blob);
            isRealHd = (dims.width >= 600 || dims.height >= 600 || blob.size >= 40000);
            resolutionCategory = 'Alta Resolução (Extração Direta WhatsApp)';

            // Se obteve timestamp nativo do WhatsApp e não havia data explícita detectada
            if (directMedia.timestamp && !meta.dateObj) {
              const nativeDate = new Date(directMedia.timestamp);
              if (!isNaN(nativeDate.getTime())) {
                const yyyy = nativeDate.getFullYear();
                const mm = String(nativeDate.getMonth() + 1).padStart(2, '0');
                const dd = String(nativeDate.getDate()).padStart(2, '0');
                meta.dateKey = `${yyyy}${mm}${dd}`;
                meta.dateStr = `${dd}/${mm}/${yyyy}`;
                meta.dateObj = nativeDate;
              }
            }
          }
        }

        // 2. FALLBACK 1: Se extração direta não obteve o blob, tenta via URL blob no DOM
        if (!blob && isBlob) {
          blob = await fetchBlobDirectly(img.src);
          if (blob && blob.size >= 600) {
            dims = await getImageDimensionsFromBlob(blob);
            if (dims.width >= 600 || dims.height >= 600 || blob.size >= 50000) {
              isRealHd = true;
              resolutionCategory = 'Alta Resolução (Chat Web)';
            } else if (dims.width >= 350 || dims.height >= 350 || blob.size >= 25000) {
              resolutionCategory = 'Média Resolução (Chat Web)';
            }
          }
        }

        // 3. FALLBACK 2: Se ainda não for HD, tenta captura pelo visualizador nativo
        if (!isRealHd && img.src && !blob) {
          const clickable = img.closest('div[role="button"], button') || img;
          const captured = await captureRealHdFromViewer(clickable);
          if (captured && captured.blob) {
            blob = captured.blob;
            dims = { width: captured.width, height: captured.height };
            isRealHd = captured.isHd;
            resolutionCategory = captured.resolutionCategory;
          } else if (!blob) {
            blob = await fetchBlobDirectly(img.src);
            if (blob) {
              dims = await getImageDimensionsFromBlob(blob);
              resolutionCategory = 'Resolução não verificada / Miniatura';
            }
          }
        }

        if (!blob || blob.size < 600) continue;

        // Salva blob no IndexedDB para não manter o payload na memória RAM
        await TempBlobStorage.store(photoKey, blob);

        const existing = photoAccumulator.get(photoKey);
        if (existing) {
          if (blob.size > existing.size || (!existing.isHd && isRealHd)) {
            photoAccumulator.set(photoKey, {
              key: photoKey,
              meta: existing.meta.dateKey ? existing.meta : meta,
              rawText: bubbleText || existing.rawText,
              isHd: isRealHd,
              isThumbnail: !isRealHd,
              resolutionCategory,
              size: blob.size,
              width: dims.width,
              height: dims.height,
              timestamp: existing.timestamp || Date.now(),
              cappedAlbum: false,
              blob: blob,
            });
          }
          continue;
        }

        photoAccumulator.set(photoKey, {
          key: photoKey,
          meta,
          rawText: bubbleText,
          isHd: isRealHd,
          isThumbnail: !isRealHd,
          resolutionCategory,
          size: blob.size,
          width: dims.width,
          height: dims.height,
          timestamp: Date.now(),
          cappedAlbum: false,
          blob: blob,
        });
        if (meta?.dateStr) {
          updateLastPhotoDateDisplay(meta.dateStr);
        }
        newlyAdded++;
      }
    }

    return newlyAdded;
  }

  function isAtBeginningOfChat() {
    const mainChat = document.querySelector('#main');
    if (!mainChat) return false;

    const groupCreatedEl = mainChat.querySelector('div[data-testid="group-chat-started"], div[data-testid="system-message"]');
    if (groupCreatedEl) {
      const rect = groupCreatedEl.getBoundingClientRect();
      const txt = (groupCreatedEl.textContent || '').toLowerCase();
      if (txt.includes('criou o grupo') || txt.includes('created group') || txt.includes('mensagens são protegidas')) {
        if (rect.top > 0 && rect.top < 320) return true;
      }
    }
    return false;
  }

  function getStableGalleryMediaId(img, dateYMD) {
    if (!img) return null;
    const container = img.closest('[data-id]') || img.closest('div[role="button"]');
    const dataId = container?.getAttribute('data-id') || img.getAttribute('data-id');
    if (dataId) return `gal_msg_${dataId}`;

    const src = img.src || '';
    if (src.startsWith('blob:')) {
      const uuid = src.replace(/^blob:[^/]+\//, '').slice(0, 36);
      if (uuid && uuid.length > 8) return `gal_blob_${uuid}`;
    }
    if (src.includes('whatsapp.net')) {
      try {
        const u = new URL(src);
        return `gal_cdn_${u.pathname.split('/').pop()}`;
      } catch (e) {}
    }

    if (src.startsWith('data:image')) {
      return `gal_thumb_${dateYMD}_${src.slice(-32)}`;
    }

    return `gal_src_${dateYMD}_${src.slice(-24)}`;
  }

  // =========================================================================
  // FLUXO DE EXECUÇÃO: INICIA VARREDURA
  // =========================================================================
  async function startScanWorkflow() {
    if (isScanning) return;
    isScanning = true;
    shouldStopScanning = false;
    currentScanRunId = Date.now();
    finishReason = 'END_OF_CHAT';
    albumCeilingWarnings.length = 0; // Limpa avisos de álbuns anteriores
    photoAccumulator.clear();
    minDateReached = null;

    // Inicia cronômetro de tempo de processamento em tempo real
    startScanTimer();

    // Garante que o IndexedDB esteja inicializado e limpo para nova execução
    await TempBlobStorage.init();
    await TempBlobStorage.clear();

    document.querySelectorAll('[data-fac-album-checked]').forEach((el) => el.removeAttribute('data-fac-album-checked'));
    document.querySelectorAll('[data-fac-download-triggered]').forEach((el) => el.removeAttribute('data-fac-download-triggered'));

    const groupInput = document.getElementById('fac-active-group-name');
    const groupName = groupInput && groupInput.value.trim() ? groupInput.value.trim() : getActiveGroupName();
    const prefixes = getPrefixesList();
    const dateLimitInput = document.getElementById('fac-date-limit');
    const dateAllCheck = document.getElementById('fac-date-all');

    const empresaInput = document.getElementById('fac-empresa');
    const areaInput = document.getElementById('fac-area');

    const userEmpresa = empresaInput ? empresaInput.value.trim() : '';
    const userArea = areaInput ? areaInput.value.trim() : '';
    const userEquipe = '';
    const namingPattern = 'EMPRESA_AREA_DATA_SEQ';
    const structure = 'empresa-data';
    const maxPhotosLimit = 0; // Sem limite de quantidade, até a data limite

    if (userEmpresa) localStorage.setItem('fac_saved_empresa', userEmpresa);
    if (userArea) localStorage.setItem('fac_saved_area', userArea);

    let targetDateLimitInt = 0;
    let limitLabel = 'sem limite de data';

    if (!dateAllCheck.checked && dateLimitInput.value) {
      const parts = dateLimitInput.value.split('-');
      if (parts.length === 3) {
        targetDateLimitInt = parseInt(parts[0], 10) * 10000 + parseInt(parts[1], 10) * 100 + parseInt(parts[2], 10);
        limitLabel = `${parts[2]}/${parts[1]}/${parts[0]}`;
      }
    }

    const liveBox = document.getElementById('fac-live-status-box');
    const startBtn = document.getElementById('fac-btn-start-auto');
    const runningActions = document.getElementById('fac-running-actions');
    const stopBtn = document.getElementById('fac-btn-stop');
    const stopCount = document.getElementById('fac-stop-count');
    const floatingCount = document.getElementById('fac-floating-count');
    const statPhotos = document.getElementById('fac-stat-photos');
    const progressFill = document.getElementById('fac-progress-fill');
    const statLastDate = document.getElementById('fac-stat-last-photo-date');

    lastCapturedPhotoDateStr = 'Nenhuma';
    if (statLastDate) statLastDate.textContent = 'Nenhuma';

    liveBox.classList.remove('hidden');
    startBtn.classList.add('hidden');
    if (runningActions) runningActions.classList.remove('hidden');
    if (stopBtn) {
      stopBtn.classList.remove('hidden');
      stopBtn.style.opacity = '1';
      stopBtn.innerHTML = '⏹️ PARAR E BAIXAR AGORA (<span id="fac-stop-count">0</span> fotos)';
    }

    stopCount.textContent = '0';
    if (floatingCount) floatingCount.textContent = '0';
    statPhotos.textContent = '0';
    progressFill.style.width = '5%';

    if (scanMode === 'gallery') {
      await runGalleryScan(groupName, structure, userEmpresa, userArea, userEquipe, namingPattern, targetDateLimitInt, limitLabel, maxPhotosLimit);
    } else {
      await runViewerContinuousScan(groupName, structure, userEmpresa, userArea, userEquipe, namingPattern, targetDateLimitInt, limitLabel, maxPhotosLimit);
    }
  }

  // =========================================================================
  // ARQUITETURA STREAM REATIVO (PRESENTE ➔ PASSADO) v2.9.7
  // Baseado na Engenharia Reversa do Virtual Scroll do WhatsApp Web:
  // 1. Sentido Único Linear (Presente ➔ Passado): sem viagens de ida e volta que quebram o React.
  // 2. Monitoramento Reativo (MutationObserver): captura cada foto no milissegundo em que entra no DOM.
  // 3. Chave Primária Estável (div[data-id]): filtro de duplicidade garantido com Set().
  // 4. Extração Imediata & Descarte de RAM: grava no IndexedDB e limpa o Blob da memória.
  // 5. Throttling Cadenciado (1.5s a 2.0s): tempo ideal para o React montar e descriptografar mídias.
  // 6. Critério de Parada Cronológica: encerra assim que o divisor/data cruzar a data limite.
  // =========================================================================
  async function runReactiveStreamScan(groupName, structure, userEmpresa, userArea, userEquipe, namingPattern, targetDateLimitInt, limitLabel, maxPhotosLimit) {
    const statusText = document.getElementById('fac-status-text');
    const progressFill = document.getElementById('fac-progress-fill');
    const stopCount = document.getElementById('fac-stop-count');
    const floatingCount = document.getElementById('fac-floating-count');
    const statPhotos = document.getElementById('fac-stat-photos');
    const prefixes = getPrefixesList();

    const limitMsg = maxPhotosLimit > 0 ? ` (Limite: ${maxPhotosLimit} fotos)` : '';
    statusText.textContent = `Iniciando extração reativa até ${limitLabel}${limitMsg}...`;

    const scrollContainer = findScrollContainer();
    if (!scrollContainer) {
      alert('Não foi possível identificar o painel de mensagens do WhatsApp. Certifique-se de que a conversa está aberta.');
      finishReason = 'ERROR';
      await finishScan(groupName, structure, userEmpresa, userArea, userEquipe, namingPattern);
      return;
    }

    const processedMsgIds = new Set();
    let consecutiveStagnantSteps = 0;
    let step = 0;
    let isExtractingBatch = false;

    // Dispara downloads prévios de mídias que estejam com ícone de download
    triggerMediaDownloads();

    /**
     * Varredura reativa de mensagens no DOM:
     * Disparada tanto pelo MutationObserver quanto a cada passo do scroll cadenciado
     */
    const extractVisibleMessages = async () => {
      if (isExtractingBatch || shouldStopScanning) return;
      isExtractingBatch = true;

      try {
        dismissUnwantedModals();
        triggerMediaDownloads();

        const messageElements = Array.from(
          scrollContainer.querySelectorAll('div[data-id], .message-in, .message-out, div[data-testid^="msg-"]')
        );

        for (const msgEl of messageElements) {
          if (shouldStopScanning) break;

          const dataId = msgEl.getAttribute('data-id') || msgEl.closest('[data-id]')?.getAttribute('data-id') || '';
          const preText = msgEl.getAttribute('data-pre-plain-text') || msgEl.querySelector('[data-pre-plain-text]')?.getAttribute('data-pre-plain-text') || '';
          const stableId = dataId || preText || `msg_node_${Math.round(msgEl.getBoundingClientRect().top)}`;

          // Se esta mensagem já foi integralmente inspecionada, pula
          if (processedMsgIds.has(stableId)) continue;

          // Localiza imagens dentro da mensagem (excluindo avatares)
          const imgs = Array.from(msgEl.querySelectorAll('img')).filter((img) => {
            if (img.closest('div[data-testid="avatar"], div[data-testid="chat-avatar"], .avatar')) return false;
            return Boolean(img.src);
          });

          // Verifica se há botão de download pendente
          const hasDownloadBtn = msgEl.querySelector(
            'div[data-testid="media-download-button"], button[data-testid="download-button"], span[data-icon="arrow-down"], span[data-icon="download"]'
          );

          if (hasDownloadBtn) {
            const btnClick = hasDownloadBtn.closest('button, div[role="button"]') || hasDownloadBtn;
            try { btnClick.click(); } catch(e) {}
          }

          // Se a mensagem não possui imagens e nem botão de download, marca como processada
          if (imgs.length === 0 && !hasDownloadBtn) {
            processedMsgIds.add(stableId);
            continue;
          }

          // Extrai metadados e data da bolha
          const bubbleText = (msgEl.innerText || '').trim();
          const meta = extractMetadataFromText(bubbleText, msgEl, prefixes);
          const photoDate = meta.dateObj;

          // Se temos uma data comprovada e atingiu a data limite:
          if (photoDate && targetDateLimitInt > 0) {
            const dateInt = photoDate.getFullYear() * 10000 + (photoDate.getMonth() + 1) * 100 + photoDate.getDate();
            if (dateInt < targetDateLimitInt) {
              finishReason = 'DATE_REACHED';
              shouldStopScanning = true;
              statusText.textContent = `Data limite alcançada (${meta.dateStr})! Concluindo...`;
              break;
            }
          }

          if (meta.dateStr) {
            updateLiveDateDisplay(meta.dateStr);
          }

          // Processa as imagens da mensagem
          if (imgs.length > 0) {
            for (let i = 0; i < imgs.length; i++) {
              if (shouldStopScanning) break;
              const img = imgs[i];
              const photoKey = `${stableId}_slot_${i}`;

              if (photoAccumulator.has(photoKey)) continue;

              const extracted = await extractBlobFromImageElement(img, dataId);
              if (extracted && extracted.blob && extracted.blob.size >= 400) {
                // Persiste imediatamente no IndexedDB para liberar RAM
                await TempBlobStorage.store(photoKey, extracted.blob);

                photoAccumulator.set(photoKey, {
                  key: photoKey,
                  meta,
                  rawText: bubbleText,
                  isHd: extracted.isHd,
                  isThumbnail: !extracted.isHd,
                  resolutionCategory: extracted.category,
                  size: extracted.blob.size,
                  width: extracted.dims.width,
                  height: extracted.dims.height,
                  timestamp: photoDate ? photoDate.getTime() : Date.now(),
                  cappedAlbum: false,
                  blob: extracted.blob,
                });

                if (meta?.dateStr) {
                  updateLastPhotoDateDisplay(meta.dateStr);
                }

                statPhotos.textContent = String(photoAccumulator.size);
                stopCount.textContent = String(photoAccumulator.size);
                if (floatingCount) floatingCount.textContent = String(photoAccumulator.size);
              }
            }
          }

          // Marca como processada
          processedMsgIds.add(stableId);
        }
      } catch (err) {
        console.warn('[Conserva_Fotos] Erro na extração de mensagens visíveis:', err);
      } finally {
        isExtractingBatch = false;
      }
    };

    // 1. Configura MutationObserver no contêiner de mensagens do chat
    const observer = new MutationObserver(() => {
      if (!shouldStopScanning) {
        extractVisibleMessages();
      }
    });

    try {
      observer.observe(scrollContainer, { childList: true, subtree: true });
    } catch (e) {
      console.warn('[Conserva_Fotos] Falha ao ativar MutationObserver:', e);
    }

    // 2. Extrai mensagens do estado inicial (presente)
    statusText.textContent = 'Coletando mídias do momento presente...';
    await extractVisibleMessages();
    await interruptibleSleep(500);

    // 3. Loop de rolagem cadenciada (Presente ➔ Passado)
    while (!shouldStopScanning) {
      if (maxPhotosLimit > 0 && photoAccumulator.size >= maxPhotosLimit) {
        finishReason = 'LIMIT_REACHED';
        statusText.textContent = `Limite configurado de ${maxPhotosLimit} fotos atingido!`;
        break;
      }

      step++;
      progressFill.style.width = `${Math.min(94, 8 + (step % 86))}%`;

      // Processa mídias visíveis
      await extractVisibleMessages();
      if (shouldStopScanning) break;

      // Verifica data limite a partir dos divisores e mensagens do topo
      const earliestDate = findEarliestVisibleDate();
      if (earliestDate) {
        if (!minDateReached || earliestDate < minDateReached) {
          minDateReached = earliestDate;
          updateLiveDateDisplay(formatDisplayDate(minDateReached));
        }

        const yr = earliestDate.getFullYear();
        const earliestDateInt = yr * 10000 + (earliestDate.getMonth() + 1) * 100 + earliestDate.getDate();

        if (targetDateLimitInt > 0 && earliestDateInt < targetDateLimitInt) {
          finishReason = 'DATE_REACHED';
          statusText.textContent = `Data limite alcançada (${formatDisplayDate(earliestDate)})! Compactando ${photoAccumulator.size} fotos...`;
          break;
        }
      }

      // Verifica início absoluto do histórico
      if (isAtBeginningOfChat()) {
        finishReason = 'END_OF_CHAT';
        statusText.textContent = 'Início absoluto do histórico alcançado!';
        break;
      }

      // Clica em banners de sincronização / mensagens antigas se houver
      clickOlderMessagesBanner();

      // Executa rolagem cadenciada para cima (em direção ao passado)
      const prevScrollTop = scrollContainer.scrollTop;
      scrollContainer.scrollTop = Math.max(0, prevScrollTop - 650);
      scrollContainer.dispatchEvent(new WheelEvent('wheel', { deltaY: -750, bubbles: true }));
      scrollContainer.dispatchEvent(new Event('scroll', { bubbles: true }));

      // Throttling essencial (1500ms a 2000ms):
      // Permite ao React do WhatsApp buscar as próximas mensagens do servidor/IndexedDB e descriptografar os Blobs
      await interruptibleSleep(1600);

      // Se o scroll chegou a 0 (topo visível):
      if (scrollContainer.scrollTop === 0) {
        consecutiveStagnantSteps++;
        statusText.textContent = `Aguardando carregamento de mensagens anteriores... (${consecutiveStagnantSteps}/6)`;

        // Empurrão suave para destravar o Infinite Scroll
        scrollContainer.scrollTop = 260;
        await interruptibleSleep(120);
        scrollContainer.scrollTop = 0;
        scrollContainer.dispatchEvent(new WheelEvent('wheel', { deltaY: -1600, bubbles: true }));
        scrollContainer.dispatchEvent(new Event('scroll', { bubbles: true }));
        clickOlderMessagesBanner();

        if (consecutiveStagnantSteps >= 6) {
          finishReason = 'END_OF_CHAT';
          statusText.textContent = 'Histórico sincronizado finalizado com sucesso.';
          break;
        }
      } else {
        consecutiveStagnantSteps = 0;
        statusText.textContent = `Varrendo histórico (${currentDateReading}) | ${photoAccumulator.size} fotos salvas`;
      }
    }

    // Desconecta o MutationObserver
    try {
      observer.disconnect();
    } catch (e) {}

    // Finalização e geração dos pacotes
    await finishScan(groupName, structure, userEmpresa, userArea, userEquipe, namingPattern);
  }

  /**
   * Localiza a imagem ou vídeo atualmente aberto no visualizador de fotos do WhatsApp Web
   */
  function findActiveViewerElement() {
    // 1. Visualizador clássico do WhatsApp
    const viewer = document.querySelector('div[data-testid="media-viewer"], div[data-testid="lightbox-wrapper"], div[data-animate-media-viewer="true"], div[data-testid="popup-media-viewer"]');
    if (viewer) {
      // Checa se o item em exibição é um VÍDEO
      const video = viewer.querySelector('video');
      const isVideo = Boolean(
        video ||
        viewer.querySelector('span[data-icon="media-play"], span[data-icon="media-pause"], button[aria-label*="Reproduzir" i], button[aria-label*="Play" i], div[data-testid="video-player"]')
      );
      if (isVideo) {
        return { viewer, img: null, isVideo: true, videoEl: video };
      }

      const img = viewer.querySelector('img[src^="blob:"]') || viewer.querySelector('img[src]');
      if (img && img.src && !img.closest('#fiscalizacampo-panel')) {
        return { viewer, img, isVideo: false };
      }
    }

    // 2. Busca por imagem de tela cheia / overlay
    const allImgs = Array.from(document.querySelectorAll('img')).filter((img) => {
      if (img.closest('#fiscalizacampo-panel') || img.closest('#fac-global-stop-bar') || img.closest('#fiscalizacampo-floating-btn')) return false;
      if (img.closest('div[data-testid="avatar"], div[data-testid="chat-avatar"]')) return false;
      const rect = img.getBoundingClientRect();
      return rect.width > 260 && rect.height > 180 && Boolean(img.src);
    });

    if (allImgs.length > 0) {
      const bestImg = allImgs[0];
      const parentContainer = bestImg.closest('div[tabindex="-1"], div[role="region"], div[style*="z-index"], div') || bestImg.parentElement;
      return { viewer: parentContainer, img: bestImg, isVideo: false };
    }

    // 3. Checa se há algum elemento de vídeo ativo no overlay
    const anyVideo = Array.from(document.querySelectorAll('video')).filter((v) => {
      if (v.closest('#fiscalizacampo-panel') || v.closest('#fac-global-stop-bar') || v.closest('#fiscalizacampo-floating-btn')) return false;
      const r = v.getBoundingClientRect();
      return r.width > 200 && r.height > 150;
    });
    if (anyVideo.length > 0) {
      const v = anyVideo[0];
      return { viewer: v.parentElement, img: null, isVideo: true, videoEl: v };
    }

    return null;
  }

  /**
   * Localiza e abre a foto mais recente da conversa de forma 100% automática,
   * pulando vídeos e rolando a conversa para cima se necessário até o visualizador abrir.
   */
  async function openFirstChatPhotoAutomatically() {
    if (findActiveViewerElement()) return true;

    const mainChat = document.querySelector('#main');
    if (!mainChat) return false;

    const scrollContainer = findScrollContainer() || mainChat;

    const dispatchFullClick = (el) => {
      if (!el) return;
      try {
        const opts = { bubbles: true, cancelable: true, view: window };
        el.dispatchEvent(new PointerEvent('pointerdown', opts));
        el.dispatchEvent(new MouseEvent('mousedown', opts));
        el.dispatchEvent(new PointerEvent('pointerup', opts));
        el.dispatchEvent(new MouseEvent('mouseup', opts));
        el.dispatchEvent(new MouseEvent('click', opts));
        if (typeof el.click === 'function') el.click();
      } catch (e) {}
    };

    const findPhotoClickables = () => {
      const candidates = Array.from(
        mainChat.querySelectorAll(
          'div[data-testid="image-thumb"], div[data-testid="media-canvas"], div[data-testid="album"], ' +
          'div[data-testid="chat-history-date-divider"] ~ div img, ' +
          '.message-in img, .message-out img, img[src^="blob:"], img[src*="whatsapp.net"]'
        )
      );

      const items = [];
      for (const el of candidates) {
        if (el.closest('#fiscalizacampo-panel') || el.closest('#fiscalizacampo-floating-btn')) continue;
        if (el.closest('div[data-testid="avatar"], div[data-testid="chat-avatar"], div[data-testid="group-chat-started"]')) continue;

        // Pula miniaturas de VÍDEO
        const bubble = el.closest('.message-in, .message-out, div[data-testid^="msg-"]');
        if (bubble) {
          const isVideoBubble = Boolean(
            bubble.querySelector('video, div[data-testid="video-thumb"], span[data-icon="media-play"], span[data-icon="video-pip"]')
          );
          if (isVideoBubble) continue;
        }

        const img = el.tagName === 'IMG' ? el : el.querySelector('img');
        const rect = el.getBoundingClientRect();
        if (rect.width >= 25 && rect.height >= 25) {
          const clickable = el.closest('div[role="button"], button, div[data-id]') || el;
          items.push({ el, clickable, img });
        }
      }
      return items;
    };

    // Tenta até 6 vezes rolando a conversa para cima até encontrar e abrir uma foto
    for (let scrollAttempt = 0; scrollAttempt < 6; scrollAttempt++) {
      if (shouldStopScanning) break;

      const items = findPhotoClickables();

      // Testa os candidatos da foto mais recente para a mais antiga
      for (let i = items.length - 1; i >= 0; i--) {
        const item = items[i];

        try {
          item.clickable.scrollIntoView({ block: 'center', behavior: 'instant' });
        } catch (e) {}
        await interruptibleSleep(120);

        dispatchFullClick(item.clickable);
        if (item.img && item.img !== item.clickable) {
          dispatchFullClick(item.img);
        }

        const opened = await waitForCondition(() => Boolean(findActiveViewerElement()), { timeoutMs: 1800, intervalMs: 60 });
        if (opened) {
          return true;
        }
      }

      // Se não abriu, clica no banner de mensagens anteriores e rola para cima
      clickOlderMessagesBanner();
      scrollContainer.scrollTop = Math.max(0, scrollContainer.scrollTop - 650);
      scrollContainer.dispatchEvent(new WheelEvent('wheel', { deltaY: -800, bubbles: true }));
      scrollContainer.dispatchEvent(new Event('scroll', { bubbles: true }));
      await interruptibleSleep(450);
    }

    return Boolean(findActiveViewerElement());
  }

  // =========================================================================
  // MODO 0 (NOVO): EXTRAÇÃO CONTÍNUA PELO VISUALIZADOR (ESTILO BAIXADOR WHATSAPP)
  // Ponto de partida na foto aberta, lê data exata no topo e avança automaticamente
  // =========================================================================
  async function runViewerContinuousScan(groupName, structure, userEmpresa, userArea, userEquipe, namingPattern, targetDateLimitInt, limitLabel, maxPhotosLimit) {
    const statusText = document.getElementById('fac-status-text');
    const progressFill = document.getElementById('fac-progress-fill');
    const stopCount = document.getElementById('fac-stop-count');
    const floatingCount = document.getElementById('fac-floating-count');
    const statPhotos = document.getElementById('fac-stat-photos');
    const prefixes = getPrefixesList();

    statusText.textContent = 'Conectando ao visualizador de fotos do WhatsApp Web...';

    let viewerData = findActiveViewerElement();

    // Se o visualizador não estiver aberto, abre a primeira foto visível do chat de forma 100% automática
    if (!viewerData) {
      statusText.textContent = 'Abrindo foto da conversa automaticamente...';
      await openFirstChatPhotoAutomatically();
      viewerData = findActiveViewerElement();
    }

    if (!viewerData) {
      statusText.textContent = 'Abra qualquer foto na conversa do WhatsApp e clique novamente em Iniciar!';
      const startBtn = document.getElementById('fac-btn-start-auto');
      const stopBtn = document.getElementById('fac-btn-stop');
      if (startBtn) startBtn.classList.remove('hidden');
      if (stopBtn) stopBtn.classList.add('hidden');
      isScanning = false;
      return;
    }

    let consecutiveUnchangedCount = 0;
    const visitedSrcs = new Set();
    const discardedThumbs = new Set();
    const thumbRetryAttempts = new Map();
    let stepCount = 0;

    while (!shouldStopScanning) {
      if (maxPhotosLimit > 0 && photoAccumulator.size >= maxPhotosLimit) {
        finishReason = 'LIMIT_REACHED';
        statusText.textContent = `Limite configurado de ${maxPhotosLimit} fotos alcançado! Compactando...`;
        break;
      }

      stepCount++;
      progressFill.style.width = `${Math.min(94, 8 + (stepCount % 86))}%`;

      // 1. Trata mensagem de imagem indisponível sem fechar o visualizador
      const dialogEl = Array.from(document.querySelectorAll('div[role="dialog"], div[data-testid="popup-contents"]')).find((d) => {
        if (d.id === 'fiscalizacampo-panel' || d.closest('#fiscalizacampo-panel') || d.closest('#fac-global-stop-bar')) return false;
        const txt = (d.innerText || d.textContent || '').toLowerCase();
        return (
          txt.includes('indisponível') ||
          txt.includes('não está mais no seu celular') ||
          txt.includes('não é possível abrir a imagem') ||
          txt.includes('falha ao baixar') ||
          txt.includes('download failed')
        );
      });

      if (dialogEl) {
        statusText.textContent = 'Foto indisponível no celular descartada. Continuando varredura...';

        const okBtn = Array.from(dialogEl.querySelectorAll('button, div[role="button"]')).find((b) => {
          const bt = (b.innerText || b.textContent || '').trim().toLowerCase();
          return bt === 'ok' || bt.includes('ok') || bt.includes('fechar') || bt.includes('entendi');
        }) || dialogEl.querySelector('button, div[role="button"]');
        if (okBtn) {
          try { okBtn.click(); } catch (e) {}
        }

        // Descarta miniatura da galeria se houver
        const galleryBar = document.querySelector('div[data-testid="media-viewer-gallery"], div[role="listbox"], div[class*="gallery"]');
        if (galleryBar) {
          const galleryImgs = Array.from(galleryBar.querySelectorAll('img'));
          const nextPendingThumb = galleryImgs.find((img) => img.src && !visitedSrcs.has(img.src) && !discardedThumbs.has(img.src));
          if (nextPendingThumb) {
            const clickEl = nextPendingThumb.closest('div[role="button"], button') || nextPendingThumb;
            try { clickEl.click(); } catch (e) {}
            await interruptibleSleep(350);
            consecutiveUnchangedCount = 0;
            continue;
          }
        }

        // Avança imediatamente para a foto mais antiga (ArrowLeft / Botão Anterior)
        window.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowLeft', code: 'ArrowLeft', keyCode: 37, bubbles: true }));
        document.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowLeft', code: 'ArrowLeft', keyCode: 37, bubbles: true }));

        const prevBtn = document.querySelector(
          'button[aria-label*="Anterior" i], div[data-testid="media-viewer-prev"], button[data-testid="media-viewer-prev"], span[data-icon="chevron-left"]'
        );
        if (prevBtn) {
          const clickTarget = prevBtn.closest('button, div[role="button"]') || prevBtn;
          try { clickTarget.click(); } catch (e) {}
        }

        await interruptibleSleep(400);
        consecutiveUnchangedCount = 0;
        continue;
      }

      // 2. Obtém a imagem atual no visualizador
      const current = findActiveViewerElement();
      const currentImg = current ? current.img : null;
      const mediaViewer = current ? current.viewer : null;

      // DETECÇÃO AUTOMÁTICA DE VÍDEO (PULA IMEDIATAMENTE SEM TRAVAR OU ESPERAR)
      if (current && current.isVideo) {
        statusText.textContent = '🎬 Vídeo no visualizador — avançando para a foto anterior...';

        window.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowLeft', code: 'ArrowLeft', keyCode: 37, bubbles: true }));
        document.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowLeft', code: 'ArrowLeft', keyCode: 37, bubbles: true }));

        const prevBtn = document.querySelector(
          'button[aria-label*="Anterior" i], div[data-testid="media-viewer-prev"], button[data-testid="media-viewer-prev"], span[data-icon="chevron-left"]'
        );
        if (prevBtn) {
          const clickTarget = prevBtn.closest('button, div[role="button"]') || prevBtn;
          try { clickTarget.click(); } catch (e) {}
        }

        const galleryBar = document.querySelector('div[data-testid="media-viewer-gallery"], div[role="listbox"], div[class*="gallery"]');
        if (galleryBar) {
          const galleryImgs = Array.from(galleryBar.querySelectorAll('img')).filter((img) => img.src && !visitedSrcs.has(img.src) && !discardedThumbs.has(img.src));
          if (galleryImgs.length > 0) {
            const nextClick = galleryImgs[0].closest('div[role="button"], button') || galleryImgs[0];
            try { nextClick.click(); } catch (e) {}
          }
        }

        await interruptibleSleep(300);
        consecutiveUnchangedCount = 0;
        continue;
      }

      // DETECÇÃO DE IMAGEM QUEBRADA
      const isImgBroken = currentImg && (currentImg.naturalWidth === 0 && currentImg.complete && !currentImg.src.startsWith('blob:'));
      if (isImgBroken) {
        if (currentImg.src) {
          discardedThumbs.add(currentImg.src);
          visitedSrcs.add(currentImg.src);
        }
        window.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowLeft', code: 'ArrowLeft', keyCode: 37, bubbles: true }));
        await interruptibleSleep(350);
        continue;
      }

      if (!currentImg) {
        consecutiveUnchangedCount++;
        // Tenta reabrir ou aguardar o visualizador
        window.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowLeft', code: 'ArrowLeft', keyCode: 37, bubbles: true }));
        await interruptibleSleep(500);
        if (consecutiveUnchangedCount >= 25) {
          finishReason = 'END_OF_CHAT';
          break;
        }
      } else if (currentImg) {
        const mediaSrc = currentImg.src;

        if (visitedSrcs.has(mediaSrc)) {
          consecutiveUnchangedCount++;

          // Tenta clicar na próxima miniatura disponível na régua inferior
          const galleryBar = document.querySelector('div[data-testid="media-viewer-gallery"], div[role="listbox"], div[class*="gallery"]');
          if (galleryBar) {
            const pendingThumbs = Array.from(galleryBar.querySelectorAll('img')).filter((thumb) => {
              const src = thumb.src || '';
              return src && !visitedSrcs.has(src) && !discardedThumbs.has(src);
            });

            if (pendingThumbs.length > 0) {
              const targetThumb = pendingThumbs[0];
              const thumbSrc = targetThumb.src || '';
              const attempts = (thumbRetryAttempts.get(thumbSrc) || 0) + 1;
              thumbRetryAttempts.set(thumbSrc, attempts);

              if (attempts >= 3) {
                discardedThumbs.add(thumbSrc);
                visitedSrcs.add(thumbSrc);
                continue;
              }

              const clickEl = targetThumb.closest('div[role="button"], button') || targetThumb;
              statusText.textContent = `Avançando para foto anterior no visualizador...`;
              try { clickEl.click(); } catch(e) {}
              await interruptibleSleep(350);
              consecutiveUnchangedCount = 0;
              continue;
            }
          }

          // Se a imagem ainda não mudou, continua enviando navegação para o passado
          if (consecutiveUnchangedCount >= 25) {
            // Fim absoluto comprovado da conversa após 25 tentativas consecutivas
            finishReason = 'END_OF_CHAT';
            break;
          }
        } else {
          visitedSrcs.add(mediaSrc);
          consecutiveUnchangedCount = 0;

          // Lê cabeçalho estrito do WhatsApp
          const headerInfo = getStrictViewerDateAndAuthor(mediaViewer);
          const captionEl = mediaViewer?.querySelector('div[data-testid="media-caption"], div[class*="caption"]');
          const captionText = (captionEl?.innerText || '').trim();

          const photoDate = headerInfo.date;
          let dateKey = '';
          let dateStr = '';
          if (photoDate) {
            const yyyy = photoDate.getFullYear();
            const mm = String(photoDate.getMonth() + 1).padStart(2, '0');
            const dd = String(photoDate.getDate()).padStart(2, '0');
            dateKey = `${yyyy}${mm}${dd}`;
            dateStr = `${dd}/${mm}/${yyyy}`;
            updateLiveDateDisplay(dateStr);
          }

          // Checa data limite estrita
          if (photoDate && targetDateLimitInt > 0) {
            const yr = photoDate.getFullYear();
            const dateInt = yr * 10000 + (photoDate.getMonth() + 1) * 100 + photoDate.getDate();
            if (dateInt < targetDateLimitInt) {
              finishReason = 'DATE_REACHED';
              statusText.textContent = `Data limite alcançada (${dateStr})! Compactando ${photoAccumulator.size} fotos...`;
              break;
            }
          }

          // Extrai o blob em resolução real
          const blob = await fetchBlobDirectly(mediaSrc);
          if (blob && blob.size >= 400) {
            const dims = await getImageDimensionsFromBlob(blob);
            const isRealHd = (dims.width >= 500 || dims.height >= 500 || blob.size >= 30000);
            const photoKey = `view_img_${mediaSrc.replace(/^blob:[^/]+\//, '').slice(-32)}_${photoAccumulator.size}`;

            await TempBlobStorage.store(photoKey, blob);

            const rawTextContext = captionText || headerInfo.rawHeader || 'Foto WhatsApp';
            const meta = extractMetadataFromText(rawTextContext, mediaViewer || document.body, prefixes);
            if (dateKey) {
              meta.dateKey = dateKey;
              meta.dateStr = dateStr;
              meta.dateObj = photoDate;
            }

            photoAccumulator.set(photoKey, {
              key: photoKey,
              meta,
              rawText: rawTextContext,
              isHd: isRealHd,
              isThumbnail: !isRealHd,
              resolutionCategory: isRealHd ? 'Alta Resolução (Visualizador WhatsApp)' : 'Média Resolução',
              size: blob.size,
              width: dims.width,
              height: dims.height,
              timestamp: photoDate ? photoDate.getTime() : Date.now(),
              cappedAlbum: false,
              blob: blob,
            });

            if (dateStr) {
              updateLastPhotoDateDisplay(dateStr);
            } else if (meta?.dateStr) {
              updateLastPhotoDateDisplay(meta.dateStr);
            }

            statPhotos.textContent = String(photoAccumulator.size);
            stopCount.textContent = String(photoAccumulator.size);
            if (floatingCount) floatingCount.textContent = String(photoAccumulator.size);
            const limitDisplay = maxPhotosLimit > 0 ? ` / ${maxPhotosLimit}` : '';
            statusText.textContent = `Visualizador: ${photoAccumulator.size}${limitDisplay} fotos | Data: ${dateStr || 'Detectando...'}`;
          }
        }
      }

      // Navegação para fotos mais antigas (passado)
      const previousSrc = currentImg ? currentImg.src : '';

      // 1. Botão "Anterior" do visualizador (seta esquerda <)
      const prevCandidates = Array.from(
        document.querySelectorAll(
          'button[aria-label*="Anterior" i], div[data-testid="media-viewer-prev"], div[aria-label*="Anterior" i], button[data-testid="media-viewer-prev"], ' +
          'span[data-icon="chevron-left"], div[role="button"]:has(span[data-icon="chevron-left"]), div[role="button"]:has(svg)'
        )
      ).filter((btn) => {
        if (btn.id === 'fiscalizacampo-panel' || btn.closest('#fiscalizacampo-panel') || btn.closest('#fac-global-stop-bar')) return false;
        const rect = btn.getBoundingClientRect();
        return rect.left < 200 && rect.top > 100 && rect.top < window.innerHeight - 100;
      });

      if (prevCandidates.length > 0) {
        const targetBtn = prevCandidates[0].closest('button, div[role="button"]') || prevCandidates[0];
        try { targetBtn.click(); } catch (e) {}
      }

      // Dispara eventos de teclado para retroceder
      window.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowLeft', code: 'ArrowLeft', keyCode: 37, bubbles: true }));
      document.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowLeft', code: 'ArrowLeft', keyCode: 37, bubbles: true }));

      // Rola a barra inferior de miniaturas para a esquerda se existir
      const galleryBar = document.querySelector('div[data-testid="media-viewer-gallery"], div[role="listbox"], div[class*="gallery"]');
      if (galleryBar) {
        try { galleryBar.scrollLeft = Math.max(0, galleryBar.scrollLeft - 250); } catch(e) {}
      }

      // Aguardo ativo: espera a nova foto aparecer no DOM
      if (previousSrc) {
        const hasChanged = await waitForCondition(() => {
          const checkCurrent = findActiveViewerElement();
          return Boolean(checkCurrent && checkCurrent.img && checkCurrent.img.src !== previousSrc);
        }, { timeoutMs: 1000, intervalMs: 50 });

        if (hasChanged) {
          await interruptibleSleep(200);
        } else {
          await interruptibleSleep(300);
        }
      } else {
        await interruptibleSleep(400);
      }
    }

    dismissUnwantedModals();
    await finishScan(groupName, structure, userEmpresa, userArea, userEquipe, namingPattern);
  }

  // =========================================================================
  // MODO 1: VARREDURA NO CHAT
  // =========================================================================
  async function runChatScan(groupName, prefixes, structure, userEmpresa, userArea, userEquipe, namingPattern, targetDateLimitInt, limitLabel, maxPhotosLimit) {
    const statusText = document.getElementById('fac-status-text');
    const progressFill = document.getElementById('fac-progress-fill');
    const stopCount = document.getElementById('fac-stop-count');
    const floatingCount = document.getElementById('fac-floating-count');
    const statPhotos = document.getElementById('fac-stat-photos');

    const limitMsg = maxPhotosLimit > 0 ? ` (Limite: ${maxPhotosLimit} fotos)` : ' (Sem limite de fotos)';
    statusText.textContent = `Iniciando varredura até ${limitLabel}${limitMsg}...`;

    const scrollContainer = findScrollContainer();
    if (!scrollContainer) {
      alert('Não foi possível identificar o painel de mensagens do WhatsApp. Certifique-se de que a conversa está aberta.');
      finishReason = 'ERROR';
      await finishScan(groupName, structure, userEmpresa, userArea, userEquipe, namingPattern);
      return;
    }

    await expandVisibleAlbums(prefixes);
    await collectVisiblePhotos(prefixes);
    statPhotos.textContent = String(photoAccumulator.size);
    stopCount.textContent = String(photoAccumulator.size);
    if (floatingCount) floatingCount.textContent = String(photoAccumulator.size);

    const initialEarliest = findEarliestVisibleDate();
    if (initialEarliest) {
      minDateReached = initialEarliest;
      updateLiveDateDisplay(formatDisplayDate(minDateReached));
    }

    let consecutiveStagnantSteps = 0;
    let step = 0;

    const getVisibleMessageAnchors = () => {
      const msgs = scrollContainer.querySelectorAll('.message-in, .message-out, div[data-testid^="msg-"]');
      return Array.from(msgs).map((el) => el.getAttribute('data-id') || el.innerText?.slice(0, 30)).filter(Boolean);
    };

    while (!shouldStopScanning) {
      if (maxPhotosLimit > 0 && photoAccumulator.size >= maxPhotosLimit) {
        finishReason = 'LIMIT_REACHED';
        statusText.textContent = `Limite configurado de ${maxPhotosLimit} fotos alcançado com sucesso! Compactando...`;
        break;
      }

      step++;
      progressFill.style.width = `${Math.min(94, 8 + (step % 86))}%`;

      dismissUnwantedModals();

      // Expande todos os álbuns visíveis em TODOS os passos (não apenas a cada 3)
      await expandVisibleAlbums(prefixes);
      if (shouldStopScanning) break;

      clickOlderMessagesBanner();

      const beforeAnchors = new Set(getVisibleMessageAnchors());

      // Rolagem suave e controlada para dar tempo à lista virtualizada do WhatsApp montar mídias
      const currentScrollTop = scrollContainer.scrollTop;
      scrollContainer.scrollTop = Math.max(0, currentScrollTop - 550);
      scrollContainer.dispatchEvent(new WheelEvent('wheel', { deltaY: -650, bubbles: true }));
      scrollContainer.dispatchEvent(new Event('scroll', { bubbles: true }));

      const anchorsChanged = await waitForCondition(() => {
        const currentAnchors = getVisibleMessageAnchors();
        return currentAnchors.some((a) => !beforeAnchors.has(a));
      }, { timeoutMs: 1600, intervalMs: 80 });

      if (shouldStopScanning) break;

      const newlyAdded = await collectVisiblePhotos(prefixes);
      statPhotos.textContent = String(photoAccumulator.size);
      stopCount.textContent = String(photoAccumulator.size);
      if (floatingCount) floatingCount.textContent = String(photoAccumulator.size);

      const earliestDate = findEarliestVisibleDate();
      if (earliestDate) {
        if (!minDateReached || earliestDate < minDateReached) {
          minDateReached = earliestDate;
          updateLiveDateDisplay(formatDisplayDate(minDateReached));
        }

        const yr = earliestDate.getFullYear();
        const earliestDateInt = yr * 10000 + (earliestDate.getMonth() + 1) * 100 + earliestDate.getDate();

        if (targetDateLimitInt > 0 && earliestDateInt < targetDateLimitInt) {
          finishReason = 'DATE_REACHED';
          statusText.textContent = `Data limite alcançada (${formatDisplayDate(earliestDate)})! Compactando ${photoAccumulator.size} fotos...`;
          break;
        }
      }

      if (isAtBeginningOfChat()) {
        finishReason = 'END_OF_CHAT';
        statusText.textContent = 'Início absoluto da conversa alcançado!';
        break;
      }

      if (!anchorsChanged && newlyAdded === 0) {
        consecutiveStagnantSteps++;
        statusText.textContent = `Aguardando carregamento de mensagens antigas... (${consecutiveStagnantSteps}/20)`;

        if (consecutiveStagnantSteps % 3 === 0) {
          clickOlderMessagesBanner();
          scrollContainer.scrollTop = 350;
          await interruptibleSleep(100);
          scrollContainer.scrollTop = 0;
          scrollContainer.dispatchEvent(new WheelEvent('wheel', { deltaY: -2200, bubbles: true }));
          scrollContainer.dispatchEvent(new Event('scroll', { bubbles: true }));
        }

        if (consecutiveStagnantSteps >= 20) {
          finishReason = 'TIMEOUT_STAGNANT';
          statusText.textContent = 'Fim provável do histórico disponível sincronizado.';
          break;
        }
      } else {
        consecutiveStagnantSteps = 0;
        const limitDisplay = maxPhotosLimit > 0 ? ` / ${maxPhotosLimit}` : '';
        statusText.textContent = `Lendo ${currentDateReading} | ${photoAccumulator.size}${limitDisplay} fotos coletadas`;
      }
    }

    await finishScan(groupName, structure, userEmpresa, userArea, userEquipe, namingPattern);
  }

  // =========================================================================
  // MODO 2: EXTRAÇÃO PELA GALERIA DE MÍDIAS
  // =========================================================================
  async function runGalleryScan(groupName, structure, userEmpresa, userArea, userEquipe, namingPattern, targetDateLimitInt, limitLabel, maxPhotosLimit) {
    const statusText = document.getElementById('fac-status-text');
    const progressFill = document.getElementById('fac-progress-fill');
    const stopCount = document.getElementById('fac-stop-count');
    const floatingCount = document.getElementById('fac-floating-count');
    const statPhotos = document.getElementById('fac-stat-photos');

    statusText.textContent = 'Abrindo Painel de Mídias do WhatsApp Web...';

    let galleryContainer = document.querySelector('div[data-testid="media-gallery-section"], div[data-testid="media-grid"]');

    if (!galleryContainer) {
      const header = document.querySelector('#main header, div[data-testid="conversation-header"]');
      if (header) {
        header.click();
        await interruptibleSleep(600);
      }

      const mediaLinksDocCandidate = Array.from(document.querySelectorAll('span, div, button')).find((el) => {
        const t = (el.textContent || '').trim().toLowerCase();
        return (t.includes('mídias, links e docs') || t.includes('media, links and docs') || (t.includes('mídia') && t.includes('links'))) && el.offsetParent !== null;
      });

      if (mediaLinksDocCandidate) {
        const clickTarget = mediaLinksDocCandidate.closest('div[role="button"], button') || mediaLinksDocCandidate;
        clickTarget.click();
        await interruptibleSleep(800);
      }
    }

    let mediaScroll = findGalleryScrollContainer();

    if (!mediaScroll) {
      statusText.textContent = 'Galeria não aberta. Alternando para o modo conversa com álbuns...';
      await interruptibleSleep(1000);
      await runChatScan(groupName, getPrefixesList(), structure, userEmpresa, userArea, userEquipe, namingPattern, targetDateLimitInt, limitLabel, maxPhotosLimit);
      return;
    }

    statusText.textContent = 'Galeria conectada! Extraindo acervo com identificação estável...';
    let galleryStep = 0;
    let stagnantCount = 0;
    let lastAccumulatorCount = 0;

    const getVisibleGalleryImageSources = () => {
      const imgs = mediaScroll.querySelectorAll('img');
      return Array.from(imgs).map((img) => img.src).filter(Boolean);
    };

    while (!shouldStopScanning) {
      if (maxPhotosLimit > 0 && photoAccumulator.size >= maxPhotosLimit) {
        finishReason = 'LIMIT_REACHED';
        statusText.textContent = `Limite configurado de ${maxPhotosLimit} fotos atingido! Concluindo...`;
        break;
      }

      galleryStep++;
      progressFill.style.width = `${Math.min(94, 10 + (galleryStep % 84))}%`;

      const gridImgs = Array.from(mediaScroll.querySelectorAll('img')).filter((img) => {
        const src = img.src || '';
        return src.startsWith('blob:') || src.startsWith('data:image') || src.includes('.whatsapp.net');
      });

      const dateHeaders = Array.from(mediaScroll.querySelectorAll('span, div, h3')).filter((el) => {
        const txt = (el.textContent || '').trim();
        return parseDateDividerText(txt) !== null && el.offsetWidth > 0;
      });

      for (let i = 0; i < gridImgs.length; i++) {
        if (shouldStopScanning) break;
        if (maxPhotosLimit > 0 && photoAccumulator.size >= maxPhotosLimit) break;

        const img = gridImgs[i];
        const rect = img.getBoundingClientRect();
        if (rect.width === 0 || rect.height === 0) continue;

        let imgDate = null;
        let closestDateHeader = null;
        for (const dh of dateHeaders) {
          const dhRect = dh.getBoundingClientRect();
          if (dhRect.top < rect.top) {
            closestDateHeader = dh;
          }
        }
        if (closestDateHeader) {
          const parsed = parseDateDividerText(closestDateHeader.textContent);
          if (parsed) imgDate = parsed;
        }

        const dateYMD = imgDate ? formatDateToYMD(imgDate).replace(/-/g, '') : '';
        const dateFormatted = imgDate ? formatDisplayDate(imgDate) : '';

        if (targetDateLimitInt > 0 && imgDate) {
          const imgDateInt = imgDate.getFullYear() * 10000 + (imgDate.getMonth() + 1) * 100 + imgDate.getDate();
          if (imgDateInt < targetDateLimitInt) {
            finishReason = 'DATE_REACHED';
            shouldStopScanning = true;
            statusText.textContent = `Data limite alcançada (${dateFormatted})!`;
            break;
          }
        }

        const photoKey = getStableGalleryMediaId(img, dateYMD);
        if (!photoKey || photoAccumulator.has(photoKey)) continue;

        let blob = null;
        let dims = { width: img.naturalWidth || 0, height: img.naturalHeight || 0 };
        let isRealHd = false;
        let resolutionCategory = 'Resolução não verificada / Miniatura';

        // 1. Tenta extração direta se o elemento contiver data-id da mensagem
        const galMsgId = img.getAttribute('data-id') || img.closest('[data-id]')?.getAttribute('data-id');
        if (galMsgId) {
          const directMedia = await requestResolveMedia(galMsgId);
          if (directMedia && directMedia.blob && directMedia.blob.size >= 600) {
            blob = directMedia.blob;
            dims = await getImageDimensionsFromBlob(blob);
            isRealHd = (dims.width >= 600 || dims.height >= 600 || blob.size >= 40000);
            resolutionCategory = 'Alta Resolução (Extração Direta WhatsApp)';
          }
        }

        // 2. Fallback: fetch da URL blob exibida
        if (!blob) {
          blob = await fetchBlobDirectly(img.src);
          if (blob && blob.size >= 600) {
            dims = await getImageDimensionsFromBlob(blob);
            if (dims.width >= 600 || dims.height >= 600 || blob.size >= 50000) {
              isRealHd = true;
              resolutionCategory = 'Alta Resolução (Galeria)';
            } else if (dims.width >= 350 || dims.height >= 350 || blob.size >= 25000) {
              resolutionCategory = 'Média Resolução (Galeria)';
            }
          }
        }

        // 3. Fallback: visualizador nativo se necessário
        if (!isRealHd && !blob) {
          const clickable = img.closest('div[role="button"], button') || img;
          const captured = await captureRealHdFromViewer(clickable);
          if (captured && captured.blob) {
            blob = captured.blob;
            dims = { width: captured.width, height: captured.height };
            isRealHd = captured.isHd;
            resolutionCategory = captured.resolutionCategory;
          }
        }

        if (blob && blob.size >= 600) {
          await TempBlobStorage.store(photoKey, blob);

          photoAccumulator.set(photoKey, {
            key: photoKey,
            meta: {
              item: 'GERAL',
              areaFrente: 'GERAL',
              km: '',
              rodovia: '',
              empresa: '',
              equipe: '',
              dateKey: dateYMD,
              dateStr: dateFormatted,
              dateObj: imgDate,
            },
            rawText: dateFormatted ? `Foto Galeria WhatsApp ${dateFormatted}` : 'Foto Galeria WhatsApp',
            isHd: isRealHd,
            isThumbnail: !isRealHd,
            resolutionCategory,
            size: blob.size,
            width: dims.width,
            height: dims.height,
            timestamp: Date.now(),
            cappedAlbum: false,
            blob: blob,
          });

          if (dateFormatted) {
            updateLastPhotoDateDisplay(dateFormatted);
          }
        }
      }

      statPhotos.textContent = String(photoAccumulator.size);
      stopCount.textContent = String(photoAccumulator.size);
      if (floatingCount) floatingCount.textContent = String(photoAccumulator.size);

      const beforeImgs = new Set(getVisibleGalleryImageSources());

      mediaScroll.scrollTop += 650;
      mediaScroll.dispatchEvent(new WheelEvent('wheel', { deltaY: 850, bubbles: true }));
      mediaScroll.dispatchEvent(new Event('scroll', { bubbles: true }));

      const newImagesRendered = await waitForCondition(() => {
        const currentImgs = getVisibleGalleryImageSources();
        return currentImgs.some((s) => !beforeImgs.has(s));
      }, { timeoutMs: 1200, intervalMs: 80 });

      if (photoAccumulator.size === lastAccumulatorCount && !newImagesRendered) {
        stagnantCount++;
        statusText.textContent = `Aguardando carregamento da galeria... (${stagnantCount}/12)`;
        if (stagnantCount >= 12) {
          finishReason = 'END_OF_CHAT';
          statusText.textContent = 'Fim das mídias disponíveis na Galeria.';
          break;
        }
      } else {
        stagnantCount = 0;
        lastAccumulatorCount = photoAccumulator.size;
        statusText.textContent = `Galeria: ${photoAccumulator.size} fotos identificadas...`;
      }
    }

    await finishScan(groupName, structure, userEmpresa, userArea, userEquipe, namingPattern);
  }

  // Helper para acionar download direto do arquivo ZIP
  async function triggerZipDownloadViaServiceWorker(zipBlob, safeZipName) {
    fallbackDomDownload(zipBlob, safeZipName);
    return true;
  }

  function fallbackDomDownload(blob, filename) {
    const url = URL.createObjectURL(blob);
    const downloadLink = document.createElement('a');
    downloadLink.href = url;
    downloadLink.download = filename;
    document.body.appendChild(downloadLink);
    downloadLink.click();
    setTimeout(() => {
      downloadLink.remove();
      URL.revokeObjectURL(url);
    }, 10000);
  }

  // =========================================================================
  // PONTO 2: FINALIZAÇÃO COM LIBERAÇÃO EFETIVA DE MEMÓRIA (INDEXEDDB & BATCH FLUSH)
  // =========================================================================
  async function finishScan(groupName, structure, userEmpresa, userArea, userEquipe, namingPattern) {
    const elapsedSeconds = stopScanTimer();
    const timeFormatted = formatElapsedTime(elapsedSeconds);
    const timeVerbose = formatElapsedTimeVerbose(elapsedSeconds);

    const progressFill = document.getElementById('fac-progress-fill');
    const statusText = document.getElementById('fac-status-text');
    const startBtn = document.getElementById('fac-btn-start-auto');
    const runningActions = document.getElementById('fac-running-actions');
    const stopBtn = document.getElementById('fac-btn-stop');

    if (runningActions) runningActions.classList.add('hidden');
    if (stopBtn) stopBtn.classList.add('hidden');

    if (finishReason === 'USER_CANCELLED_NO_DOWNLOAD') {
      if (statusText) statusText.textContent = '⏹️ Varredura cancelada pelo usuário. Nenhum arquivo foi baixado.';
      if (startBtn) startBtn.classList.remove('hidden');
      if (progressFill) progressFill.style.width = '0%';
      isScanning = false;
      return;
    }

    if (progressFill) progressFill.style.width = '92%';

    try {
      const finalPhotoList = Array.from(photoAccumulator.values());

      if (finalPhotoList.length === 0) {
        if (statusText) statusText.textContent = `Nenhuma foto encontrada (${timeVerbose} de busca).`;
        if (startBtn) startBtn.classList.remove('hidden');
        isScanning = false;
        return;
      }

      if (statusText) statusText.textContent = `Empacotando ${finalPhotoList.length} fotos (${timeVerbose} decorridos)...`;
      await ensureLibrariesLoaded();

      const finalJSZip = window.JSZip || (typeof JSZip !== 'undefined' ? JSZip : null);
      if (!finalJSZip) {
        alert('Não foi possível carregar a biblioteca JSZip. Verifique a instalação da extensão.');
        if (startBtn) startBtn.classList.remove('hidden');
        isScanning = false;
        return;
      }

      const localNow = new Date();
      const todayLocal = formatDateToYMD(localNow).replace(/-/g, '');

      const defaultEmpresa = userEmpresa || 'EMPRESA';
      const defaultArea = userArea || 'AREA';

      const allRecords = [];
      const countPerPrefix = new Map();

      for (let idx = 0; idx < finalPhotoList.length; idx++) {
        const item = finalPhotoList[idx];
        const itemMeta = item?.meta || {};
        const isDateValid = Boolean(itemMeta.dateKey && itemMeta.dateKey.length === 8 && itemMeta.dateKey !== 'SEM_DATA' && !isNaN(Number(itemMeta.dateKey)));
        const photoDateKey = isDateValid ? itemMeta.dateKey : 'SEM_DATA';
        const photoDateFormatted = isDateValid ? itemMeta.dateStr : 'Não identificada';

        const fotoEmpresa = userEmpresa || itemMeta.empresa || defaultEmpresa;
        const fotoArea = userArea || itemMeta.areaFrente || itemMeta.item || defaultArea;
        const fotoGrupo = groupName || 'GRUPO';

        const safeEmpresa = sanitizeForFilename(fotoEmpresa, 'EMPRESA');
        const safeArea = sanitizeForFilename(fotoArea, 'AREA');
        const safeGrupo = sanitizeForFilename(fotoGrupo, 'CONVERSA');

        const seqKey = `${safeEmpresa}_${safeGrupo}_${safeArea}_${photoDateKey}`;
        const currentSeq = (countPerPrefix.get(seqKey) || 0) + 1;
        countPerPrefix.set(seqKey, currentSeq);

        const seq = String(currentSeq).padStart(3, '0');

        // Nome do arquivo com base na hierarquia EMPRESA_CONVERSA_AREA
        let fileName = `${safeEmpresa}_${safeGrupo}_${safeArea}_${photoDateKey}_${seq}.jpg`;
        if (item.isUnavailable) {
          fileName = `INDISPONIVEL_${safeEmpresa}_${safeGrupo}_${safeArea}_${photoDateKey}_${seq}.jpg`;
        }
        // Pasta organizada em EMPRESA/CONVERSA/AREA (e subpasta por data do dia)
        let folderPath = `${safeEmpresa}/${safeGrupo}/${safeArea}/${photoDateKey}`;

        const obsList = [];
        if (item.cappedAlbum) {
          obsList.push(`⚠️ Álbum interrompido no limite de segurança (${MAX_ALBUM_PHOTOS} fotos) - verifique manualmente se há fotos adicionais no chat`);
        }
        if (!isDateValid) {
          obsList.push(`Data não identificada no WhatsApp (armazenada em pasta SEM_DATA)`);
        }
        if (item.isUnavailable) {
          obsList.push(`⚠️ Mídia Indisponível / Falha de Servidor (mantido registro na planilha para auditoria)`);
        }
        const observacaoAuditoria = obsList.join(' | ');

        allRecords.push({
          key: item.key,
          Arquivo: fileName,
          Pasta: folderPath,
          Empresa: fotoEmpresa,
          Conversa: fotoGrupo,
          Area_Frente: fotoArea,
          Item: itemMeta.item || '-',
          km: itemMeta.km || '-',
          Rodovia: itemMeta.rodovia || '-',
          Data_Detectada: photoDateFormatted,
          Resolucao: item.resolutionCategory || 'Resolução não verificada / Miniatura',
          Dimensoes: item.width && item.height ? `${item.width}x${item.height} px` : 'Mídia Indisponível',
          Tamanho_KB: Math.round((item.size || 0) / 1024),
          Observacoes: observacaoAuditoria,
          Texto_Original: (item.rawText || '').replace(/\n+/g, ' ').slice(0, 180),
          fallbackBlob: item.blob,
        });
      }

      const totalBatches = Math.ceil(allRecords.length / MAX_PHOTOS_PER_ZIP_BATCH);
      let batchesSuccessfullyDownloaded = 0;

      for (let b = 0; b < totalBatches; b++) {
        const batchRecords = allRecords.slice(b * MAX_PHOTOS_PER_ZIP_BATCH, (b + 1) * MAX_PHOTOS_PER_ZIP_BATCH);
        const batchNum = b + 1;
        const batchSuffix = totalBatches > 1 ? `_Parte_${batchNum}_de_${totalBatches}` : '';

        if (statusText) statusText.textContent = `Compactando lote ${batchNum} de ${totalBatches} (${batchRecords.length} fotos)...`;

        let zip = new finalJSZip();

        // Carrega no JSZip os blobs do lote atual
        for (const rec of batchRecords) {
          let blob = null;
          if (TempBlobStorage.isAvailable()) {
            try {
              blob = await TempBlobStorage.retrieve(rec.key);
            } catch (e) {}
          }
          if (!blob) {
            blob = rec.fallbackBlob;
          }

          if (blob) {
            zip.file(`${rec.Pasta}/${rec.Arquivo}`, blob);
          }
        }

        // Adiciona a planilha Excel do lote
        try {
          if (window.XLSX) {
            const excelData = batchRecords.map(({ fallbackBlob, key, ...rest }) => rest);
            const ws = window.XLSX.utils.json_to_sheet(excelData);
            const wb = window.XLSX.utils.book_new();
            window.XLSX.utils.book_append_sheet(wb, ws, 'Indice_Fotos');
            const wbout = window.XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
            const xlsxName = totalBatches > 1 ? `INDICE_CAMPOS_Parte_${batchNum}.xlsx` : 'INDICE_E_CONFERENCIA_CAMPOS.xlsx';
            zip.file(xlsxName, wbout);
          }
        } catch (e) {
          console.warn('[Conserva_Fotos] Erro ao anexar planilha XLSX:', e);
        }

        try {
          const zipBlob = await zip.generateAsync({ type: 'blob', compression: 'STORE' });
          const safeZipName = `Conserva_Fotos_${sanitizeForFilename(defaultEmpresa, 'EMPRESA')}_${sanitizeForFilename(groupName, 'CONVERSA')}_${sanitizeForFilename(defaultArea, 'AREA')}_${todayLocal}${batchSuffix}.zip`;

          await triggerZipDownloadViaServiceWorker(zipBlob, safeZipName);

          batchesSuccessfullyDownloaded++;

          // =====================================================================
          // LIBERAÇÃO EFETIVA DE MEMÓRIA:
          // Exclui os blobs deste lote do IndexedDB e apaga referências do mapa imediatamente
          // =====================================================================
          for (const rec of batchRecords) {
            if (TempBlobStorage.isAvailable()) {
              try { await TempBlobStorage.remove(rec.key); } catch(e) {}
            }
            rec.fallbackBlob = null;
            photoAccumulator.delete(rec.key);
          }

          zip = null;

        } catch (err) {
          console.error('[Conserva_Fotos] Falha ao gerar arquivo ZIP:', err);
          if (statusText) statusText.textContent = `Erro ao compactar lote ${batchNum}: ${err.message}`;
          if (startBtn) startBtn.classList.remove('hidden');
          isScanning = false;
          return;
        }

        if (totalBatches > 1 && b < totalBatches - 1) {
          await interruptibleSleep(600);
        }
      }

      // Limpa qualquer resíduo restante do IndexedDB
      try { await TempBlobStorage.clear(); } catch(e) {}

      if (progressFill) progressFill.style.width = '100%';

      const batchInfo = totalBatches > 1 ? ` em ${batchesSuccessfullyDownloaded} arquivos ZIP divididos` : '';
      let statusMsg = '';

      if (finishReason === 'USER_STOPPED') {
        statusMsg = `⏹️ Coleta interrompida: ${allRecords.length} fotos salvas em ${timeVerbose}${batchInfo} com planilha Excel.`;
      } else if (finishReason === 'LIMIT_REACHED') {
        statusMsg = `ℹ️ Limite atingido: ${allRecords.length} fotos salvas em ${timeVerbose}${batchInfo} com planilha Excel.`;
      } else if (finishReason === 'DATE_REACHED') {
        statusMsg = `📅 Data limite alcançada: ${allRecords.length} fotos salvas em ${timeVerbose}${batchInfo} com planilha Excel.`;
      } else if (finishReason === 'TIMEOUT_STAGNANT') {
        statusMsg = `⏱️ Histórico sincronizado concluído (Watchdog 15s): ${allRecords.length} fotos salvas em ${timeVerbose}${batchInfo} com planilha Excel.`;
      } else {
        statusMsg = `✅ Coleta concluída! ${allRecords.length} fotos salvas em ${timeVerbose}${batchInfo} com planilha Excel.`;
      }

      if (albumCeilingWarnings.length > 0) {
        statusMsg += ` ⚠️ Atenção: ${albumCeilingWarnings.length} álbum(ns) com +${MAX_ALBUM_PHOTOS} fotos atingiram o teto de segurança e foram interrompidos.`;
      }

      if (statusText) statusText.textContent = statusMsg;

    } catch (fatalScanErr) {
      console.error('[Conserva_Fotos] Erro fatal no empacotamento:', fatalScanErr);
      if (statusText) statusText.textContent = `⚠️ Erro ao empacotar: ${fatalScanErr.message}. Tente novamente.`;
    } finally {
      if (runningActions) runningActions.classList.add('hidden');
      if (stopBtn) {
        stopBtn.classList.add('hidden');
        stopBtn.style.opacity = '1';
        stopBtn.innerHTML = '⏹️ PARAR E BAIXAR AGORA (<span id="fac-stop-count">0</span> fotos)';
      }
      if (startBtn) startBtn.classList.remove('hidden');
      isScanning = false;
    }
  }

  // Inicialização no WhatsApp Web
  const interval = setInterval(() => {
    if (document.querySelector('#app') || document.querySelector('#main') || document.body) {
      initExtensionUI();
      clearInterval(interval);
    }
  }, 1000);
})();
